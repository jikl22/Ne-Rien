import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ArticlePage } from './pages/ArticlePage';
import { CategoryPage } from './pages/CategoryPage';
import { SearchPage } from './pages/SearchPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { ArticleProvider, useArticles } from './context/ArticleContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SiteSettingsProvider } from './context/SiteSettingsContext';
import { TranslationProvider } from './context/TranslationContext';
import { AuthorsProvider } from './context/AuthorsContext';
import { Article } from './data/articles';

type ViewType = 'home' | 'article' | 'category' | 'search' | 'admin';

interface AppState {
  view: ViewType;
  articleSlug?: string;
  categoryId?: string;
  searchQuery?: string;
}

function AppContent() {
  const [state, setState] = useState<AppState>({ view: 'home' });
  const [article, setArticle] = useState<Article | null>(null);
  const { isAuthenticated } = useAuth();
  const { getArticleBySlug } = useArticles();

  // Scroll to top on view change
  useEffect(() => {
    if (state.view !== 'admin') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [state.view, state.articleSlug, state.categoryId]);

  // Load article when viewing article page
  useEffect(() => {
    if (state.view === 'article' && state.articleSlug) {
      const foundArticle = getArticleBySlug(state.articleSlug);
      setArticle(foundArticle || null);
      
      // Update document title for SEO
      if (foundArticle) {
        document.title = `${foundArticle.title} | NE RIEN Magazine`;
        
        // Update meta description
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
          metaDesc.setAttribute('content', foundArticle.excerpt);
        }
      }
    } else {
      setArticle(null);
      if (state.view !== 'admin') {
        document.title = 'NE RIEN Magazine | Fashion News, Trends & Culture';
      }
    }
  }, [state.view, state.articleSlug, getArticleBySlug]);

  const handleNavigate = (view: string, data?: string) => {
    switch (view) {
      case 'home':
        setState({ view: 'home' });
        break;
      case 'article':
        setState({ view: 'article', articleSlug: data });
        break;
      case 'category':
        setState({ view: 'category', categoryId: data });
        break;
      case 'search':
        setState({ view: 'search', searchQuery: data });
        break;
      case 'admin':
        setState({ view: 'admin' });
        break;
      default:
        setState({ view: 'home' });
    }
  };

  const handleArticleClick = (slug: string) => {
    handleNavigate('article', slug);
  };

  const handleCategoryClick = (categoryId: string) => {
    handleNavigate('category', categoryId);
  };

  const getCurrentView = () => {
    if (state.view === 'category' && state.categoryId) {
      return `category-${state.categoryId}`;
    }
    return state.view;
  };

  // Admin Views
  if (state.view === 'admin') {
    if (!isAuthenticated) {
      return (
        <AdminLoginPage 
          onLoginSuccess={() => setState({ view: 'admin' })}
          onBackToSite={() => setState({ view: 'home' })}
        />
      );
    }
    return (
      <AdminDashboard 
        onBackToSite={() => setState({ view: 'home' })}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ fontFamily: "'Inter', sans-serif" }}>
      <Header currentView={getCurrentView()} onNavigate={handleNavigate} />
      
      <div className="flex-1">
        {state.view === 'home' && (
          <HomePage 
            onArticleClick={handleArticleClick} 
            onCategoryClick={handleCategoryClick} 
          />
        )}
        
        {state.view === 'article' && article && (
          <ArticlePage 
            article={article} 
            onArticleClick={handleArticleClick}
            onCategoryClick={handleCategoryClick}
          />
        )}
        
        {state.view === 'article' && !article && state.articleSlug && (
          <div className="max-w-7xl mx-auto px-6 py-20 text-center">
            <h1 
              className="text-3xl font-serif font-bold mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Article not found
            </h1>
            <p className="text-gray-600 mb-8">The article you're looking for doesn't exist.</p>
            <button
              onClick={() => handleNavigate('home')}
              className="px-8 py-3 bg-black text-white uppercase tracking-wider text-sm font-medium hover:bg-gray-800 transition-colors"
            >
              Return Home
            </button>
          </div>
        )}
        
        {state.view === 'category' && state.categoryId && (
          <CategoryPage 
            categoryId={state.categoryId} 
            onArticleClick={handleArticleClick} 
          />
        )}
        
        {state.view === 'search' && (
          <SearchPage 
            query={state.searchQuery || ''} 
            onArticleClick={handleArticleClick} 
          />
        )}
      </div>
      
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <TranslationProvider>
        <SiteSettingsProvider>
          <AuthorsProvider>
            <ArticleProvider>
              <AppContent />
            </ArticleProvider>
          </AuthorsProvider>
        </SiteSettingsProvider>
      </TranslationProvider>
    </AuthProvider>
  );
}
