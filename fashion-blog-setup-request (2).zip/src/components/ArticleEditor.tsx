import { useState } from 'react';
import { Article, categories } from '../data/articles';
import { useArticles } from '../context/ArticleContext';
import { useAuthors } from '../context/AuthorsContext';
import { RichTextEditor } from './RichTextEditor';
import { translateText, translateHTML } from '../utils/translate';

interface ArticleEditorProps {
  article?: Article;
  onSave: () => void;
  onCancel: () => void;
}

export function ArticleEditor({ article, onSave, onCancel }: ArticleEditorProps) {
  const { addArticle, updateArticle } = useArticles();
  const { authors } = useAuthors();
  const isEditing = !!article;
  const [authorMode, setAuthorMode] = useState<'select' | 'custom'>(article?.author ? 'custom' : 'select');

  const [formData, setFormData] = useState({
    title: article?.title || '',
    slug: article?.slug || '',
    excerpt: article?.excerpt || '',
    content: article?.content || '',
    category: article?.category || 'news',
    author: article?.author || '',
    authorImage: article?.authorImage || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100',
    date: article?.date || new Date().toISOString().split('T')[0],
    image: article?.image || '',
    featured: article?.featured || false,
    readTime: article?.readTime || '5 min',
    // Spanish content
    titleEs: (article as any)?.titleEs || '',
    excerptEs: (article as any)?.excerptEs || '',
    contentEs: (article as any)?.contentEs || '',
  });

  const [showSpanish, setShowSpanish] = useState(false);
  const [translating, setTranslating] = useState<'title' | 'excerpt' | 'content' | 'all' | null>(null);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [previewImage, setPreviewImage] = useState(true);

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  };

  const handleTitleChange = (title: string) => {
    setFormData(prev => ({
      ...prev,
      title,
      slug: isEditing ? prev.slug : generateSlug(title),
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) newErrors.title = 'Title is required';
    if (!formData.slug.trim()) newErrors.slug = 'Slug is required';
    if (!formData.excerpt.trim()) newErrors.excerpt = 'Excerpt is required';
    if (!formData.content.trim()) newErrors.content = 'Content is required';
    if (!formData.author.trim()) newErrors.author = 'Author is required';
    if (!formData.image.trim()) newErrors.image = 'Image URL is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    if (isEditing && article) {
      updateArticle(article.id, formData as Partial<Article>);
    } else {
      addArticle(formData as Omit<Article, 'id'>);
    }

    onSave();
  };

  return (
    <div className="bg-white shadow-sm">
      <div className="p-6 border-b border-gray-100">
        <h2 
          className="text-2xl font-bold"
          style={{ fontFamily: "'Playfair Display', serif" }}
        >
          {isEditing ? 'Edit Article' : 'Create New Article'}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="p-6">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Title *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                className={`w-full px-4 py-3 border ${errors.title ? 'border-red-300' : 'border-gray-200'} focus:outline-none focus:border-black text-lg`}
                placeholder="Enter article title"
              />
              {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
            </div>

            {/* Slug */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                URL Slug *
              </label>
              <div className="flex items-center">
                <span className="text-gray-400 text-sm mr-2">/article/</span>
                <input
                  type="text"
                  value={formData.slug}
                  onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                  className={`flex-1 px-4 py-2 border ${errors.slug ? 'border-red-300' : 'border-gray-200'} focus:outline-none focus:border-black`}
                  placeholder="article-url-slug"
                />
              </div>
              {errors.slug && <p className="text-red-500 text-sm mt-1">{errors.slug}</p>}
            </div>

            {/* Excerpt */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Excerpt * <span className="text-gray-400 font-normal">({formData.excerpt.length}/300)</span>
              </label>
              <textarea
                value={formData.excerpt}
                onChange={(e) => setFormData(prev => ({ ...prev, excerpt: e.target.value }))}
                rows={3}
                maxLength={300}
                className={`w-full px-4 py-3 border ${errors.excerpt ? 'border-red-300' : 'border-gray-200'} focus:outline-none focus:border-black resize-none`}
                placeholder="Brief summary of the article (shown in article cards)"
              />
              {errors.excerpt && <p className="text-red-500 text-sm mt-1">{errors.excerpt}</p>}
            </div>

            {/* Content */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Content * <span className="text-gray-400 font-normal">(Use toolbar to format)</span>
              </label>
              <RichTextEditor
                value={formData.content}
                onChange={(content) => setFormData(prev => ({ ...prev, content }))}
                error={errors.content}
              />
            </div>

            {/* Spanish Content Section */}
            <div className="border-2 border-amber-200 rounded-lg overflow-hidden">
              <button
                type="button"
                onClick={() => setShowSpanish(!showSpanish)}
                className="w-full px-4 py-3 bg-amber-50 flex items-center justify-between hover:bg-amber-100 transition-colors"
              >
                <span className="font-medium flex items-center gap-2">
                  🇪🇸 Spanish Content (Contenido en Español)
                  {(formData.titleEs || formData.excerptEs || formData.contentEs) && (
                    <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded">Has content</span>
                  )}
                </span>
                <span className="text-xl">{showSpanish ? '−' : '+'}</span>
              </button>
              
              {showSpanish && (
                <div className="p-4 space-y-4 bg-amber-50/30">
                  {/* Auto-translate all button */}
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={async () => {
                        if (!formData.title && !formData.excerpt && !formData.content) {
                          alert('Please write the English content first');
                          return;
                        }
                        setTranslating('all');
                        try {
                          const [titleEs, excerptEs, contentEs] = await Promise.all([
                            formData.title ? translateText(formData.title, 'en', 'es') : '',
                            formData.excerpt ? translateText(formData.excerpt, 'en', 'es') : '',
                            formData.content ? translateHTML(formData.content, 'en', 'es') : '',
                          ]);
                          setFormData(prev => ({ ...prev, titleEs, excerptEs, contentEs }));
                        } catch (error) {
                          alert('Translation failed. Please try again.');
                        }
                        setTranslating(null);
                      }}
                      disabled={translating !== null}
                      className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 disabled:bg-gray-400 flex items-center gap-2"
                    >
                      {translating === 'all' ? (
                        <>
                          <span className="animate-spin">⏳</span>
                          Translating...
                        </>
                      ) : (
                        <>
                          🔄 Auto-translate All from English
                        </>
                      )}
                    </button>
                  </div>

                  {/* Spanish Title */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Título (Spanish Title)
                      </label>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!formData.title) return;
                          setTranslating('title');
                          const titleEs = await translateText(formData.title, 'en', 'es');
                          setFormData(prev => ({ ...prev, titleEs }));
                          setTranslating(null);
                        }}
                        disabled={translating !== null || !formData.title}
                        className="text-xs text-blue-600 hover:text-blue-800 disabled:text-gray-400"
                      >
                        {translating === 'title' ? '⏳ Translating...' : '🔄 Translate from English'}
                      </button>
                    </div>
                    <input
                      type="text"
                      value={formData.titleEs}
                      onChange={(e) => setFormData(prev => ({ ...prev, titleEs: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-200 focus:outline-none focus:border-black"
                      placeholder="Título del artículo en español"
                    />
                  </div>

                  {/* Spanish Excerpt */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Extracto (Spanish Excerpt)
                      </label>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!formData.excerpt) return;
                          setTranslating('excerpt');
                          const excerptEs = await translateText(formData.excerpt, 'en', 'es');
                          setFormData(prev => ({ ...prev, excerptEs }));
                          setTranslating(null);
                        }}
                        disabled={translating !== null || !formData.excerpt}
                        className="text-xs text-blue-600 hover:text-blue-800 disabled:text-gray-400"
                      >
                        {translating === 'excerpt' ? '⏳ Translating...' : '🔄 Translate from English'}
                      </button>
                    </div>
                    <textarea
                      value={formData.excerptEs}
                      onChange={(e) => setFormData(prev => ({ ...prev, excerptEs: e.target.value }))}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-200 focus:outline-none focus:border-black resize-none"
                      placeholder="Breve resumen del artículo en español"
                    />
                  </div>

                  {/* Spanish Content */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-700">
                        Contenido (Spanish Content)
                      </label>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!formData.content) return;
                          setTranslating('content');
                          const contentEs = await translateHTML(formData.content, 'en', 'es');
                          setFormData(prev => ({ ...prev, contentEs }));
                          setTranslating(null);
                        }}
                        disabled={translating !== null || !formData.content}
                        className="text-xs text-blue-600 hover:text-blue-800 disabled:text-gray-400"
                      >
                        {translating === 'content' ? '⏳ Translating...' : '🔄 Translate from English'}
                      </button>
                    </div>
                    <RichTextEditor
                      value={formData.contentEs}
                      onChange={(contentEs) => setFormData(prev => ({ ...prev, contentEs }))}
                    />
                  </div>

                  <p className="text-xs text-gray-500 bg-white p-3 rounded border">
                    💡 <strong>Tip:</strong> Auto-translation uses a free service (MyMemory). 
                    For best results, review and edit the translated text. 
                    When visitors switch to Spanish, they'll see this content instead of the English version.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Featured Image */}
            <div className="bg-gray-50 p-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Featured Image URL *
              </label>
              <input
                type="url"
                value={formData.image}
                onChange={(e) => { setFormData(prev => ({ ...prev, image: e.target.value })); setPreviewImage(true); }}
                className={`w-full px-3 py-2 border ${errors.image ? 'border-red-300' : 'border-gray-200'} focus:outline-none focus:border-black text-sm`}
                placeholder="https://images.unsplash.com/..."
              />
              {errors.image && <p className="text-red-500 text-sm mt-1">{errors.image}</p>}
              
              {formData.image && previewImage && (
                <div className="mt-3 aspect-video bg-gray-200 overflow-hidden">
                  <img
                    src={formData.image}
                    alt="Preview"
                    className="w-full h-full object-cover"
                    onError={() => setPreviewImage(false)}
                  />
                </div>
              )}
              <p className="text-xs text-gray-400 mt-2">
                Tip: Use Unsplash for free images (e.g., https://images.unsplash.com/photo-xxx?w=1200)
              </p>
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value as Article['category'] }))}
                className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black bg-white"
              >
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            {/* Author */}
            <div className="bg-gray-50 p-4 rounded">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Author *
              </label>
              
              {/* Author Mode Toggle */}
              <div className="flex gap-2 mb-3">
                <button
                  type="button"
                  onClick={() => setAuthorMode('select')}
                  className={`px-3 py-1 text-xs font-medium rounded ${
                    authorMode === 'select' 
                      ? 'bg-black text-white' 
                      : 'bg-white text-gray-600 border'
                  }`}
                >
                  Select Author
                </button>
                <button
                  type="button"
                  onClick={() => setAuthorMode('custom')}
                  className={`px-3 py-1 text-xs font-medium rounded ${
                    authorMode === 'custom' 
                      ? 'bg-black text-white' 
                      : 'bg-white text-gray-600 border'
                  }`}
                >
                  Custom Name
                </button>
              </div>

              {authorMode === 'select' && authors.length > 0 ? (
                <div className="space-y-2">
                  <select
                    value={authors.find(a => a.name === formData.author)?.id || ''}
                    onChange={(e) => {
                      const selected = authors.find(a => a.id === e.target.value);
                      if (selected) {
                        setFormData(prev => ({
                          ...prev,
                          author: selected.name,
                          authorImage: selected.photo
                        }));
                      }
                    }}
                    className={`w-full px-4 py-2 border ${errors.author ? 'border-red-300' : 'border-gray-200'} focus:outline-none focus:border-black bg-white`}
                  >
                    <option value="">-- Select an author --</option>
                    {authors.map(author => (
                      <option key={author.id} value={author.id}>
                        {author.name} {author.role ? `(${author.role})` : ''}
                      </option>
                    ))}
                  </select>
                  {errors.author && <p className="text-red-500 text-sm mt-1">{errors.author}</p>}
                  
                  {/* Selected Author Preview */}
                  {formData.author && (
                    <div className="flex items-center gap-3 p-2 bg-white rounded border mt-2">
                      {formData.authorImage && (
                        <img
                          src={formData.authorImage}
                          alt={formData.author}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                      )}
                      <span className="text-sm font-medium">{formData.author}</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <input
                    type="text"
                    value={formData.author}
                    onChange={(e) => setFormData(prev => ({ ...prev, author: e.target.value }))}
                    className={`w-full px-4 py-2 border ${errors.author ? 'border-red-300' : 'border-gray-200'} focus:outline-none focus:border-black`}
                    placeholder="Author name"
                  />
                  {errors.author && <p className="text-red-500 text-sm mt-1">{errors.author}</p>}
                  
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">
                      Author Photo URL
                    </label>
                    <input
                      type="url"
                      value={formData.authorImage}
                      onChange={(e) => setFormData(prev => ({ ...prev, authorImage: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-200 focus:outline-none focus:border-black text-sm"
                      placeholder="https://..."
                    />
                  </div>
                  
                  {formData.authorImage && (
                    <div className="flex items-center gap-3">
                      <img
                        src={formData.authorImage}
                        alt="Author"
                        className="w-10 h-10 rounded-full object-cover"
                        onError={(e) => (e.currentTarget.style.display = 'none')}
                      />
                      <span className="text-sm text-gray-500">{formData.author || 'Author preview'}</span>
                    </div>
                  )}
                </div>
              )}

              {authors.length === 0 && authorMode === 'select' && (
                <p className="text-xs text-gray-500 mt-2">
                  No authors yet. Go to "👤 Authors" tab to add team members.
                </p>
              )}
            </div>

            {/* Date */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Publish Date
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black"
              />
            </div>

            {/* Read Time */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Read Time
              </label>
              <input
                type="text"
                value={formData.readTime}
                onChange={(e) => setFormData(prev => ({ ...prev, readTime: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black"
                placeholder="5 min"
              />
            </div>

            {/* Featured */}
            <div className="bg-amber-50 p-4 border border-amber-100">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.featured}
                  onChange={(e) => setFormData(prev => ({ ...prev, featured: e.target.checked }))}
                  className="w-5 h-5 accent-black"
                />
                <div>
                  <span className="font-medium">Featured Article</span>
                  <p className="text-xs text-gray-500">Shows in hero section on homepage</p>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4 mt-8 pt-6 border-t border-gray-100">
          <button
            type="submit"
            className="px-8 py-3 bg-black text-white font-medium uppercase tracking-wider text-sm hover:bg-gray-800 transition-colors"
          >
            {isEditing ? 'Update Article' : 'Publish Article'}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-8 py-3 border border-gray-300 text-gray-700 font-medium uppercase tracking-wider text-sm hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
