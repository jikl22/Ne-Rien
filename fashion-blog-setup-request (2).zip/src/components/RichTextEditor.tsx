import { useState, useRef, useCallback } from 'react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

interface Footnote {
  id: number;
  text: string;
}

export function RichTextEditor({ value, onChange, error }: RichTextEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [showImageModal, setShowImageModal] = useState(false);
  const [showFootnoteModal, setShowFootnoteModal] = useState(false);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  
  // Image modal state
  const [imageUrl, setImageUrl] = useState('');
  const [imageCaption, setImageCaption] = useState('');
  const [imageAlign, setImageAlign] = useState<'left' | 'center' | 'right' | 'full'>('full');
  
  // Footnote state
  const [footnotes, setFootnotes] = useState<Footnote[]>(() => {
    // Parse existing footnotes from content
    const footnoteSection = value.match(/<div class="footnotes">([\s\S]*?)<\/div>/);
    const existingFootnotes: Footnote[] = [];
    
    if (footnoteSection) {
      const footnoteMatches = footnoteSection[1].matchAll(/<p class="text-sm text-gray-600 mb-2"><sup>(\d+)<\/sup>\s*(.*?)\s*<a/g);
      for (const match of footnoteMatches) {
        existingFootnotes.push({ id: parseInt(match[1]), text: match[2] });
      }
    }
    
    return existingFootnotes;
  });
  const [newFootnoteText, setNewFootnoteText] = useState('');
  
  // Link modal state
  const [linkUrl, setLinkUrl] = useState('');
  const [linkText, setLinkText] = useState('');

  const insertAtCursor = useCallback((textBefore: string, textAfter: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    const newText = value.substring(0, start) + textBefore + selectedText + textAfter + value.substring(end);
    
    onChange(newText);
    
    // Restore cursor position
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + textBefore.length + selectedText.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  }, [value, onChange]);

  const wrapSelection = useCallback((tag: string, attributes: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end) || 'Your text here';
    
    const openTag = attributes ? `<${tag} ${attributes}>` : `<${tag}>`;
    const closeTag = `</${tag}>`;
    const newText = value.substring(0, start) + openTag + selectedText + closeTag + value.substring(end);
    
    onChange(newText);
    
    setTimeout(() => {
      textarea.focus();
    }, 0);
  }, [value, onChange]);

  const insertImage = () => {
    if (!imageUrl) return;
    
    let alignClass = '';
    let style = '';
    
    switch (imageAlign) {
      case 'left':
        alignClass = 'float-left mr-6 mb-4';
        style = 'max-width: 50%;';
        break;
      case 'right':
        alignClass = 'float-right ml-6 mb-4';
        style = 'max-width: 50%;';
        break;
      case 'center':
        alignClass = 'mx-auto block';
        style = 'max-width: 80%;';
        break;
      case 'full':
        alignClass = 'w-full';
        style = 'width: 100%;';
        break;
    }
    
    let imageHtml = `\n<figure class="my-8">\n  <img src="${imageUrl}" alt="${imageCaption}" class="${alignClass}" style="${style}" />\n`;
    
    if (imageCaption) {
      imageHtml += `  <figcaption class="text-center text-sm text-gray-500 mt-2 italic">${imageCaption}</figcaption>\n`;
    }
    
    imageHtml += `</figure>\n`;
    
    insertAtCursor(imageHtml);
    
    // Reset and close modal
    setImageUrl('');
    setImageCaption('');
    setImageAlign('full');
    setShowImageModal(false);
  };

  const insertFootnote = () => {
    if (!newFootnoteText) return;
    
    const newId = footnotes.length + 1;
    const newFootnotes = [...footnotes, { id: newId, text: newFootnoteText }];
    setFootnotes(newFootnotes);
    
    // Insert footnote reference at cursor
    const footnoteRef = `<sup class="footnote-ref"><a href="#fn${newId}" id="fnref${newId}">[${newId}]</a></sup>`;
    insertAtCursor(footnoteRef);
    
    // Update or create footnotes section at the end
    updateFootnotesSection(newFootnotes);
    
    setNewFootnoteText('');
    setShowFootnoteModal(false);
  };

  const updateFootnotesSection = (updatedFootnotes: Footnote[]) => {
    // Remove existing footnotes section if present
    let newContent = value.replace(/<div class="footnotes">[\s\S]*?<\/div>/, '');
    
    // Create new footnotes section
    if (updatedFootnotes.length > 0) {
      let footnotesHtml = '\n\n<div class="footnotes">\n  <hr class="my-8" />\n  <h4 class="text-sm font-bold uppercase tracking-wider mb-4">Footnotes</h4>\n';
      
      updatedFootnotes.forEach(fn => {
        footnotesHtml += `  <p class="text-sm text-gray-600 mb-2"><sup>${fn.id}</sup> ${fn.text} <a href="#fnref${fn.id}" class="text-gray-400">↩</a></p>\n`;
      });
      
      footnotesHtml += '</div>';
      newContent += footnotesHtml;
    }
    
    onChange(newContent);
  };

  const removeFootnote = (id: number) => {
    const newFootnotes = footnotes.filter(fn => fn.id !== id);
    // Renumber remaining footnotes
    const renumberedFootnotes = newFootnotes.map((fn, index) => ({
      ...fn,
      id: index + 1
    }));
    setFootnotes(renumberedFootnotes);
    
    // Remove footnote reference from content
    let newContent = value.replace(new RegExp(`<sup class="footnote-ref"><a href="#fn${id}" id="fnref${id}">\\[${id}\\]</a></sup>`, 'g'), '');
    
    // Update remaining references
    footnotes.forEach((fn, index) => {
      if (fn.id > id) {
        const oldId = fn.id;
        const newId = index;
        newContent = newContent.replace(
          new RegExp(`<sup class="footnote-ref"><a href="#fn${oldId}" id="fnref${oldId}">\\[${oldId}\\]</a></sup>`, 'g'),
          `<sup class="footnote-ref"><a href="#fn${newId}" id="fnref${newId}">[${newId}]</a></sup>`
        );
      }
    });
    
    onChange(newContent);
    updateFootnotesSection(renumberedFootnotes);
  };

  const insertLink = () => {
    if (!linkUrl) return;
    
    const text = linkText || linkUrl;
    const linkHtml = `<a href="${linkUrl}" target="_blank" rel="noopener noreferrer" class="text-black underline hover:no-underline">${text}</a>`;
    
    insertAtCursor(linkHtml);
    
    setLinkUrl('');
    setLinkText('');
    setShowLinkModal(false);
  };

  const toolbarButtons = [
    { label: 'H2', action: () => wrapSelection('h2', 'class="text-2xl font-bold mt-8 mb-4"'), title: 'Heading 2' },
    { label: 'H3', action: () => wrapSelection('h3', 'class="text-xl font-bold mt-6 mb-3"'), title: 'Heading 3' },
    { label: 'B', action: () => wrapSelection('strong'), title: 'Bold', style: 'font-bold' },
    { label: 'I', action: () => wrapSelection('em'), title: 'Italic', style: 'italic' },
    { label: 'P', action: () => wrapSelection('p', 'class="mb-4"'), title: 'Paragraph' },
    { label: '❝', action: () => wrapSelection('blockquote', 'class="border-l-4 border-black pl-6 italic my-6"'), title: 'Quote' },
    { label: '•', action: () => insertAtCursor('<ul class="list-disc pl-6 mb-4">\n  <li>', '</li>\n</ul>'), title: 'Bullet List' },
    { label: '1.', action: () => insertAtCursor('<ol class="list-decimal pl-6 mb-4">\n  <li>', '</li>\n</ol>'), title: 'Numbered List' },
  ];

  return (
    <div className="border border-gray-200">
      {/* Toolbar */}
      <div className="bg-gray-50 border-b border-gray-200 p-2 flex flex-wrap gap-1 items-center">
        {/* Text formatting */}
        <div className="flex gap-1 pr-2 border-r border-gray-300">
          {toolbarButtons.map((btn, i) => (
            <button
              key={i}
              type="button"
              onClick={btn.action}
              title={btn.title}
              className={`px-3 py-1.5 text-sm border border-gray-300 bg-white hover:bg-gray-100 transition-colors ${btn.style || ''}`}
            >
              {btn.label}
            </button>
          ))}
        </div>

        {/* Insert buttons */}
        <div className="flex gap-1 px-2 border-r border-gray-300">
          <button
            type="button"
            onClick={() => setShowLinkModal(true)}
            title="Insert Link"
            className="px-3 py-1.5 text-sm border border-gray-300 bg-white hover:bg-gray-100 transition-colors"
          >
            🔗 Link
          </button>
          <button
            type="button"
            onClick={() => setShowImageModal(true)}
            title="Insert Image"
            className="px-3 py-1.5 text-sm border border-gray-300 bg-white hover:bg-gray-100 transition-colors"
          >
            📷 Image
          </button>
          <button
            type="button"
            onClick={() => setShowFootnoteModal(true)}
            title="Add Footnote"
            className="px-3 py-1.5 text-sm border border-gray-300 bg-white hover:bg-gray-100 transition-colors"
          >
            ¹ Footnote
          </button>
        </div>

        {/* Special inserts */}
        <div className="flex gap-1 px-2 border-r border-gray-300">
          <button
            type="button"
            onClick={() => insertAtCursor('<hr class="my-8 border-t border-gray-300" />\n')}
            title="Horizontal Line"
            className="px-3 py-1.5 text-sm border border-gray-300 bg-white hover:bg-gray-100 transition-colors"
          >
            ― Line
          </button>
          <button
            type="button"
            onClick={() => insertAtCursor('<p class="text-lg font-medium text-gray-700 my-6 leading-relaxed">', '</p>')}
            title="Lead Paragraph"
            className="px-3 py-1.5 text-sm border border-gray-300 bg-white hover:bg-gray-100 transition-colors"
          >
            ¶ Lead
          </button>
        </div>

        {/* Preview toggle */}
        <div className="ml-auto">
          <button
            type="button"
            onClick={() => setShowPreview(!showPreview)}
            className={`px-4 py-1.5 text-sm font-medium transition-colors ${
              showPreview 
                ? 'bg-black text-white' 
                : 'border border-gray-300 bg-white hover:bg-gray-100'
            }`}
          >
            {showPreview ? '✏️ Edit' : '👁️ Preview'}
          </button>
        </div>
      </div>

      {/* Editor / Preview */}
      {showPreview ? (
        <div 
          className="p-6 min-h-[400px] prose prose-lg max-w-none bg-white"
          dangerouslySetInnerHTML={{ __html: value }}
        />
      ) : (
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={18}
          className={`w-full px-4 py-3 focus:outline-none resize-y font-mono text-sm ${error ? 'bg-red-50' : ''}`}
          placeholder="Start writing your article...

<p>Your first paragraph here...</p>

<h2>Section Heading</h2>
<p>More content...</p>

Use the toolbar above to format text, add images, and insert footnotes!"
        />
      )}
      {error && <p className="text-red-500 text-sm px-4 py-2 bg-red-50">{error}</p>}

      {/* Footnotes Manager */}
      {footnotes.length > 0 && (
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <h4 className="text-sm font-bold mb-2">Footnotes ({footnotes.length})</h4>
          <div className="space-y-2">
            {footnotes.map(fn => (
              <div key={fn.id} className="flex items-start gap-2 text-sm">
                <span className="font-bold text-gray-500">[{fn.id}]</span>
                <span className="flex-1 text-gray-600">{fn.text}</span>
                <button
                  type="button"
                  onClick={() => removeFootnote(fn.id)}
                  className="text-red-500 hover:text-red-700 text-xs"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Image Modal */}
      {showImageModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg shadow-xl">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="font-bold text-lg">Insert Image</h3>
              <button onClick={() => setShowImageModal(false)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL *</label>
                <input
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 focus:outline-none focus:border-black"
                  placeholder="https://images.unsplash.com/..."
                />
              </div>
              
              {imageUrl && (
                <div className="aspect-video bg-gray-100 overflow-hidden">
                  <img src={imageUrl} alt="Preview" className="w-full h-full object-cover" />
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Caption (optional)</label>
                <input
                  type="text"
                  value={imageCaption}
                  onChange={(e) => setImageCaption(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 focus:outline-none focus:border-black"
                  placeholder="Photo by John Doe / Unsplash"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Alignment</label>
                <div className="flex gap-2">
                  {(['left', 'center', 'right', 'full'] as const).map(align => (
                    <button
                      key={align}
                      type="button"
                      onClick={() => setImageAlign(align)}
                      className={`px-4 py-2 text-sm border capitalize ${
                        imageAlign === align 
                          ? 'bg-black text-white border-black' 
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {align}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-4 border-t border-gray-200 flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowImageModal(false)}
                className="px-4 py-2 text-sm border border-gray-300 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={insertImage}
                disabled={!imageUrl}
                className="px-4 py-2 text-sm bg-black text-white hover:bg-gray-800 disabled:bg-gray-300"
              >
                Insert Image
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footnote Modal */}
      {showFootnoteModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg shadow-xl">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="font-bold text-lg">Add Footnote</h3>
              <button onClick={() => setShowFootnoteModal(false)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <div className="p-4">
              <p className="text-sm text-gray-500 mb-4">
                Footnotes appear at the bottom of your article. A reference number [1] will be inserted at your cursor position.
              </p>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Footnote #{footnotes.length + 1}
              </label>
              <textarea
                value={newFootnoteText}
                onChange={(e) => setNewFootnoteText(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-200 focus:outline-none focus:border-black resize-none"
                placeholder="Enter your footnote text, citation, or reference..."
              />
            </div>
            <div className="p-4 border-t border-gray-200 flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowFootnoteModal(false)}
                className="px-4 py-2 text-sm border border-gray-300 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={insertFootnote}
                disabled={!newFootnoteText}
                className="px-4 py-2 text-sm bg-black text-white hover:bg-gray-800 disabled:bg-gray-300"
              >
                Add Footnote
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Link Modal */}
      {showLinkModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg shadow-xl">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="font-bold text-lg">Insert Link</h3>
              <button onClick={() => setShowLinkModal(false)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">URL *</label>
                <input
                  type="url"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 focus:outline-none focus:border-black"
                  placeholder="https://example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Link Text (optional)</label>
                <input
                  type="text"
                  value={linkText}
                  onChange={(e) => setLinkText(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 focus:outline-none focus:border-black"
                  placeholder="Click here (leave empty to use URL)"
                />
              </div>
            </div>
            <div className="p-4 border-t border-gray-200 flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowLinkModal(false)}
                className="px-4 py-2 text-sm border border-gray-300 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={insertLink}
                disabled={!linkUrl}
                className="px-4 py-2 text-sm bg-black text-white hover:bg-gray-800 disabled:bg-gray-300"
              >
                Insert Link
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
