import { useState } from 'react';
import { useSiteSettings } from '../context/SiteSettingsContext';
import { useTranslation } from '../context/TranslationContext';
import { cn } from '../utils/cn';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string, data?: string) => void;
}

export function Header({ currentView, onNavigate }: HeaderProps) {
  const { settings } = useSiteSettings();
  const { language, setLanguage, t } = useTranslation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('search', searchQuery);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-100">
      {/* Top bar */}
      <div className="hidden lg:block bg-black text-white text-xs py-2">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <span>The destination for fashion-forward individuals</span>
          <div className="flex gap-6">
            <a href="#newsletter" className="hover:underline">Newsletter</a>
            <a href="#subscribe" className="hover:underline">Subscribe</a>
          </div>
        </div>
      </div>
      
      {/* Main header */}
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Menu button - visible on all screens */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 -ml-2 hover:bg-gray-100 rounded transition-colors"
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>

          {/* Logo */}
          <button 
            onClick={() => onNavigate('home')}
            className="font-serif text-2xl lg:text-4xl font-bold tracking-wider hover:opacity-70 transition-opacity"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {settings.logoText}
          </button>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {/* Language Switcher */}
            <div className="flex items-center border border-gray-200 rounded overflow-hidden">
              <button
                onClick={() => setLanguage('en')}
                className={cn(
                  "px-2 py-1 text-xs font-medium transition-colors",
                  language === 'en' 
                    ? "bg-black text-white" 
                    : "bg-white text-gray-600 hover:bg-gray-100"
                )}
                title="English"
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('es')}
                className={cn(
                  "px-2 py-1 text-xs font-medium transition-colors",
                  language === 'es' 
                    ? "bg-black text-white" 
                    : "bg-white text-gray-600 hover:bg-gray-100"
                )}
                title="Español"
              >
                ES
              </button>
            </div>
            
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2"
              aria-label={t.search}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
            <button
              onClick={() => onNavigate('admin')}
              className="p-2 text-gray-400 hover:text-black transition-colors"
              aria-label={t.admin}
              title={t.adminPanel}
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center justify-center gap-8 py-4 border-t border-gray-50">
          {settings.navLinks.filter(link => link.enabled).map((link) => {
            const isCategory = link.path.startsWith('/category/');
            const categoryId = isCategory ? link.path.replace('/category/', '') : null;
            const isActive = link.path === '/' 
              ? currentView === 'home'
              : categoryId 
                ? currentView === `category-${categoryId}`
                : false;
            
            return (
              <button
                key={link.path}
                onClick={() => {
                  if (link.path === '/') {
                    onNavigate('home');
                  } else if (categoryId) {
                    onNavigate('category', categoryId);
                  }
                }}
                className={cn(
                  "text-xs tracking-widest uppercase font-medium hover:text-gray-500 transition-colors",
                  isActive && "text-black underline underline-offset-4"
                )}
              >
                {link.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Search overlay */}
      {searchOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-lg">
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto p-6">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full px-4 py-3 pr-12 border border-gray-300 focus:outline-none focus:border-black text-lg"
                autoFocus
              />
              <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2">
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Dropdown menu - works on all screens */}
      {mobileMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-lg z-50">
          <nav className="max-w-7xl mx-auto flex flex-col py-4">
            {settings.navLinks.filter(link => link.enabled).map((link) => {
              const isCategory = link.path.startsWith('/category/');
              const categoryId = isCategory ? link.path.replace('/category/', '') : null;
              const isActive = link.path === '/' 
                ? currentView === 'home'
                : categoryId 
                  ? currentView === `category-${categoryId}`
                  : false;
              
              return (
                <button
                  key={link.path}
                  onClick={() => {
                    if (link.path === '/') {
                      onNavigate('home');
                    } else if (categoryId) {
                      onNavigate('category', categoryId);
                    }
                    setMobileMenuOpen(false);
                  }}
                  className={cn(
                    "px-6 py-3 text-left text-sm tracking-widest uppercase font-medium hover:bg-gray-50 transition-colors",
                    isActive && "bg-gray-100 border-l-4 border-black"
                  )}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
}
