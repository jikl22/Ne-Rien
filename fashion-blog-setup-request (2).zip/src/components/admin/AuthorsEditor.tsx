import React, { useState } from 'react';
import { useAuthors, Author } from '../../context/AuthorsContext';
import { useTranslation } from '../../context/TranslationContext';

export const AuthorsEditor: React.FC = () => {
  const { authors, addAuthor, updateAuthor, deleteAuthor } = useAuthors();
  const { t } = useTranslation();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState<Omit<Author, 'id'>>({
    name: '',
    photo: '',
    role: '',
    bio: '',
    email: '',
    instagram: '',
    twitter: '',
    website: ''
  });

  const resetForm = () => {
    setFormData({
      name: '',
      photo: '',
      role: '',
      bio: '',
      email: '',
      instagram: '',
      twitter: '',
      website: ''
    });
    setEditingId(null);
    setShowAddForm(false);
  };

  const handleEdit = (author: Author) => {
    setFormData({
      name: author.name,
      photo: author.photo,
      role: author.role,
      bio: author.bio,
      email: author.email || '',
      instagram: author.instagram || '',
      twitter: author.twitter || '',
      website: author.website || ''
    });
    setEditingId(author.id);
    setShowAddForm(true);
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      alert('Author name is required');
      return;
    }

    if (editingId) {
      updateAuthor(editingId, formData);
    } else {
      addAuthor(formData);
    }
    resetForm();
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteAuthor(id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">👤 {t.author}s</h2>
        {!showAddForm && (
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-black text-white px-4 py-2 rounded hover:bg-gray-800 flex items-center gap-2"
          >
            <span>+</span> Add Author
          </button>
        )}
      </div>

      {/* Add/Edit Form */}
      {showAddForm && (
        <div className="bg-gray-50 p-6 rounded-lg border">
          <h3 className="font-bold mb-4">
            {editingId ? t.edit + ' ' + t.author : 'Add New Author'}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Left Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Name *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="Isabella Chen"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Role / Title
                </label>
                <input
                  type="text"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="Fashion Director"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  {t.authorPhoto}
                </label>
                <input
                  type="url"
                  value={formData.photo}
                  onChange={(e) => setFormData({ ...formData, photo: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="https://example.com/photo.jpg"
                />
                {formData.photo && (
                  <img 
                    src={formData.photo} 
                    alt="Preview" 
                    className="mt-2 w-20 h-20 rounded-full object-cover"
                  />
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Biography
                </label>
                <textarea
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  className="w-full border rounded px-3 py-2 h-32"
                  placeholder="Write a short bio about this author..."
                />
              </div>
            </div>

            {/* Right Column - Contact & Social */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  📧 Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="author@email.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  📸 Instagram URL
                </label>
                <input
                  type="url"
                  value={formData.instagram}
                  onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="https://instagram.com/username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  🐦 Twitter URL
                </label>
                <input
                  type="url"
                  value={formData.twitter}
                  onChange={(e) => setFormData({ ...formData, twitter: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="https://twitter.com/username"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  🌐 Website
                </label>
                <input
                  type="url"
                  value={formData.website}
                  onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                  className="w-full border rounded px-3 py-2"
                  placeholder="https://mywebsite.com"
                />
              </div>
            </div>
          </div>

          <div className="flex gap-2 mt-6">
            <button
              onClick={handleSave}
              className="bg-black text-white px-6 py-2 rounded hover:bg-gray-800"
            >
              {editingId ? t.saveChanges : 'Add Author'}
            </button>
            <button
              onClick={resetForm}
              className="bg-gray-300 text-gray-700 px-6 py-2 rounded hover:bg-gray-400"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      )}

      {/* Authors List */}
      <div className="grid gap-4">
        {authors.map((author) => (
          <div 
            key={author.id} 
            className="bg-white border rounded-lg p-4 flex items-start gap-4 hover:shadow-md transition-shadow"
          >
            {/* Photo */}
            <div className="flex-shrink-0">
              {author.photo ? (
                <img 
                  src={author.photo} 
                  alt={author.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center text-2xl">
                  👤
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-grow">
              <h3 className="font-bold text-lg">{author.name}</h3>
              {author.role && (
                <p className="text-gray-600 text-sm">{author.role}</p>
              )}
              {author.bio && (
                <p className="text-gray-500 text-sm mt-1 line-clamp-2">{author.bio}</p>
              )}
              
              {/* Social Icons */}
              <div className="flex gap-3 mt-2">
                {author.email && (
                  <span className="text-gray-400 text-sm">📧</span>
                )}
                {author.instagram && (
                  <span className="text-gray-400 text-sm">📸</span>
                )}
                {author.twitter && (
                  <span className="text-gray-400 text-sm">🐦</span>
                )}
                {author.website && (
                  <span className="text-gray-400 text-sm">🌐</span>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2 flex-shrink-0">
              <button
                onClick={() => handleEdit(author)}
                className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                title={t.edit}
              >
                ✏️
              </button>
              <button
                onClick={() => handleDelete(author.id, author.name)}
                className="p-2 text-red-600 hover:bg-red-50 rounded"
                title={t.delete}
              >
                🗑️
              </button>
            </div>
          </div>
        ))}

        {authors.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <p className="text-4xl mb-2">👤</p>
            <p>No authors yet. Add your first author!</p>
          </div>
        )}
      </div>
    </div>
  );
};
