import React, { useState } from 'react';
import { useSiteSettings, SiteSettings } from '../../context/SiteSettingsContext';

type TabType = 'branding' | 'seo' | 'content' | 'social' | 'categories' | 'navigation';

export const SiteSettingsEditor: React.FC = () => {
  const { settings, updateSettings, resetSettings } = useSiteSettings();
  const [activeTab, setActiveTab] = useState<TabType>('branding');
  const [saved, setSaved] = useState(false);
  const [localSettings, setLocalSettings] = useState<SiteSettings>(settings);

  const handleSave = () => {
    updateSettings(localSettings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleReset = () => {
    if (confirm('Are you sure you want to reset all site settings to default? This cannot be undone.')) {
      resetSettings();
      window.location.reload();
    }
  };

  const updateLocal = (key: keyof SiteSettings, value: any) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const updateCategory = (index: number, field: string, value: string) => {
    const newCategories = [...localSettings.categories];
    newCategories[index] = { ...newCategories[index], [field]: value };
    setLocalSettings(prev => ({ ...prev, categories: newCategories }));
  };

  const updateNavLink = (index: number, field: string, value: any) => {
    const newLinks = [...localSettings.navLinks];
    newLinks[index] = { ...newLinks[index], [field]: value };
    setLocalSettings(prev => ({ ...prev, navLinks: newLinks }));
  };

  // Add new category
  const addCategory = () => {
    const newId = `category-${Date.now()}`;
    const newCategory = {
      id: newId,
      name: 'New Category',
      description: 'Description of your new category'
    };
    setLocalSettings(prev => ({
      ...prev,
      categories: [...prev.categories, newCategory],
      // Also add a nav link for this category
      navLinks: [...prev.navLinks, { label: 'New Category', path: `/category/${newId}`, enabled: true }]
    }));
  };

  // Delete category
  const deleteCategory = (index: number) => {
    const categoryId = localSettings.categories[index].id;
    if (confirm(`Delete category "${localSettings.categories[index].name}"? This cannot be undone.`)) {
      setLocalSettings(prev => ({
        ...prev,
        categories: prev.categories.filter((_, i) => i !== index),
        // Also remove the nav link for this category
        navLinks: prev.navLinks.filter(link => link.path !== `/category/${categoryId}`)
      }));
    }
  };

  // Move category up/down
  const moveCategory = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= localSettings.categories.length) return;
    
    const newCategories = [...localSettings.categories];
    [newCategories[index], newCategories[newIndex]] = [newCategories[newIndex], newCategories[index]];
    setLocalSettings(prev => ({ ...prev, categories: newCategories }));
  };

  // Add new navigation link
  const addNavLink = () => {
    const newLink = {
      label: 'New Link',
      path: '/new-page',
      enabled: true
    };
    setLocalSettings(prev => ({
      ...prev,
      navLinks: [...prev.navLinks, newLink]
    }));
  };

  // Delete navigation link
  const deleteNavLink = (index: number) => {
    const link = localSettings.navLinks[index];
    if (link.path === '/') {
      alert('You cannot delete the Home link.');
      return;
    }
    if (confirm(`Delete navigation link "${link.label}"?`)) {
      setLocalSettings(prev => ({
        ...prev,
        navLinks: prev.navLinks.filter((_, i) => i !== index)
      }));
    }
  };

  // Move nav link up/down
  const moveNavLink = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= localSettings.navLinks.length) return;
    
    const newLinks = [...localSettings.navLinks];
    [newLinks[index], newLinks[newIndex]] = [newLinks[newIndex], newLinks[index]];
    setLocalSettings(prev => ({ ...prev, navLinks: newLinks }));
  };

  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: 'branding', label: 'Branding', icon: '🏷️' },
    { id: 'seo', label: 'SEO', icon: '🔍' },
    { id: 'content', label: 'Content', icon: '📝' },
    { id: 'social', label: 'Social', icon: '🔗' },
    { id: 'categories', label: 'Categories', icon: '📁' },
    { id: 'navigation', label: 'Navigation', icon: '🧭' },
  ];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Site Settings</h2>
          <p className="text-gray-600">Customize your website's content and appearance</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleReset}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Reset to Default
          </button>
          <button
            onClick={handleSave}
            className="px-6 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-2"
          >
            {saved ? '✓ Saved!' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id 
                ? 'border-black text-black' 
                : 'border-transparent text-gray-500 hover:text-black'
            }`}
          >
            <span>{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Branding Tab */}
      {activeTab === 'branding' && (
        <div className="space-y-6 max-w-2xl">
          <div>
            <label className="block text-sm font-medium mb-2">Site Name</label>
            <input
              type="text"
              value={localSettings.siteName}
              onChange={e => updateLocal('siteName', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="ÉLAN"
            />
            <p className="text-sm text-gray-500 mt-1">The main name of your website</p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Logo Text</label>
            <input
              type="text"
              value={localSettings.logoText}
              onChange={e => updateLocal('logoText', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="ÉLAN"
            />
            <p className="text-sm text-gray-500 mt-1">Text displayed in the header logo</p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Tagline</label>
            <input
              type="text"
              value={localSettings.siteTagline}
              onChange={e => updateLocal('siteTagline', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="The Art of Fashion"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Site Description</label>
            <textarea
              value={localSettings.siteDescription}
              onChange={e => updateLocal('siteDescription', e.target.value)}
              rows={3}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="Your premier destination for fashion..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Footer Copyright Text</label>
            <input
              type="text"
              value={localSettings.footerCopyright}
              onChange={e => updateLocal('footerCopyright', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="© 2024 ÉLAN Magazine. All rights reserved."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Footer About Text</label>
            <textarea
              value={localSettings.footerAbout}
              onChange={e => updateLocal('footerAbout', e.target.value)}
              rows={4}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>
      )}

      {/* SEO Tab */}
      {activeTab === 'seo' && (
        <div className="space-y-6 max-w-2xl">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h3 className="font-medium text-blue-800 mb-1">📈 SEO Tips</h3>
            <p className="text-sm text-blue-700">
              These settings help search engines understand and rank your website.
              Keep your title under 60 characters and description under 160 characters.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">SEO Title</label>
            <input
              type="text"
              value={localSettings.seoTitle}
              onChange={e => updateLocal('seoTitle', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
            <p className="text-sm text-gray-500 mt-1">
              {localSettings.seoTitle.length}/60 characters
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">SEO Description</label>
            <textarea
              value={localSettings.seoDescription}
              onChange={e => updateLocal('seoDescription', e.target.value)}
              rows={3}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
            <p className="text-sm text-gray-500 mt-1">
              {localSettings.seoDescription.length}/160 characters
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Keywords</label>
            <input
              type="text"
              value={localSettings.seoKeywords}
              onChange={e => updateLocal('seoKeywords', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="fashion, style, trends..."
            />
            <p className="text-sm text-gray-500 mt-1">Separate keywords with commas</p>
          </div>
        </div>
      )}

      {/* Content Tab */}
      {activeTab === 'content' && (
        <div className="space-y-6 max-w-2xl">
          <h3 className="font-semibold text-lg">Hero Section</h3>
          <div>
            <label className="block text-sm font-medium mb-2">Hero Title</label>
            <input
              type="text"
              value={localSettings.heroTitle}
              onChange={e => updateLocal('heroTitle', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Hero Subtitle</label>
            <input
              type="text"
              value={localSettings.heroSubtitle}
              onChange={e => updateLocal('heroSubtitle', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <hr className="my-6" />

          <h3 className="font-semibold text-lg">Newsletter Section</h3>
          <div>
            <label className="block text-sm font-medium mb-2">Newsletter Title</label>
            <input
              type="text"
              value={localSettings.newsletterTitle}
              onChange={e => updateLocal('newsletterTitle', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Newsletter Subtitle</label>
            <textarea
              value={localSettings.newsletterSubtitle}
              onChange={e => updateLocal('newsletterSubtitle', e.target.value)}
              rows={2}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Button Text</label>
            <input
              type="text"
              value={localSettings.newsletterButtonText}
              onChange={e => updateLocal('newsletterButtonText', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <hr className="my-6" />

          <h3 className="font-semibold text-lg">Contact Information</h3>
          <div>
            <label className="block text-sm font-medium mb-2">Email</label>
            <input
              type="email"
              value={localSettings.contactEmail}
              onChange={e => updateLocal('contactEmail', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Address</label>
            <input
              type="text"
              value={localSettings.contactAddress}
              onChange={e => updateLocal('contactAddress', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
            />
          </div>
        </div>
      )}

      {/* Social Tab */}
      {activeTab === 'social' && (
        <div className="space-y-6 max-w-2xl">
          <p className="text-gray-600 mb-4">Add your social media profile URLs. Leave empty to hide the icon.</p>

          <div>
            <label className="block text-sm font-medium mb-2">📸 Instagram</label>
            <input
              type="url"
              value={localSettings.socialInstagram}
              onChange={e => updateLocal('socialInstagram', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="https://instagram.com/yourusername"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">🐦 Twitter / X</label>
            <input
              type="url"
              value={localSettings.socialTwitter}
              onChange={e => updateLocal('socialTwitter', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="https://twitter.com/yourusername"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">👤 Facebook</label>
            <input
              type="url"
              value={localSettings.socialFacebook}
              onChange={e => updateLocal('socialFacebook', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="https://facebook.com/yourpage"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">📌 Pinterest</label>
            <input
              type="url"
              value={localSettings.socialPinterest}
              onChange={e => updateLocal('socialPinterest', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="https://pinterest.com/yourusername"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">▶️ YouTube</label>
            <input
              type="url"
              value={localSettings.socialYoutube}
              onChange={e => updateLocal('socialYoutube', e.target.value)}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
              placeholder="https://youtube.com/yourchannel"
            />
          </div>
        </div>
      )}

      {/* Categories Tab */}
      {activeTab === 'categories' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-gray-600">Add, remove, and reorder your categories. Categories appear in navigation and organize your articles.</p>
            <button
              onClick={addCategory}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add Category
            </button>
          </div>

          <div className="space-y-3">
            {localSettings.categories.map((category, index) => (
              <div key={category.id} className="border rounded-lg p-4 bg-white">
                <div className="flex items-center gap-3 mb-3">
                  {/* Reorder buttons */}
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => moveCategory(index, 'up')}
                      disabled={index === 0}
                      className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Move up"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                      </svg>
                    </button>
                    <button
                      onClick={() => moveCategory(index, 'down')}
                      disabled={index === localSettings.categories.length - 1}
                      className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Move down"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                  </div>
                  
                  <span className="bg-gray-100 px-2 py-1 rounded text-xs font-mono text-gray-500">{category.id}</span>
                  
                  <div className="flex-1" />
                  
                  {/* Delete button */}
                  <button
                    onClick={() => deleteCategory(index)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete category"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Display Name</label>
                    <input
                      type="text"
                      value={category.name}
                      onChange={e => updateCategory(index, 'name', e.target.value)}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
                      placeholder="Category name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Description</label>
                    <input
                      type="text"
                      value={category.description}
                      onChange={e => updateCategory(index, 'description', e.target.value)}
                      className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
                      placeholder="Brief description"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {localSettings.categories.length === 0 && (
            <div className="text-center py-8 border-2 border-dashed rounded-lg">
              <p className="text-gray-500">No categories yet. Click "Add Category" to create one.</p>
            </div>
          )}
        </div>
      )}

      {/* Navigation Tab */}
      {activeTab === 'navigation' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600">Add, remove, and reorder navigation links. You can link to categories or custom pages.</p>
              <p className="text-sm text-gray-400 mt-1">Tip: Use "/category/your-id" to link to a category page, or any URL for external links.</p>
            </div>
            <button
              onClick={addNavLink}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add Link
            </button>
          </div>

          <div className="space-y-3">
            {localSettings.navLinks.map((link, index) => (
              <div key={`${link.path}-${index}`} className="flex items-center gap-3 border rounded-lg p-4 bg-white">
                {/* Reorder buttons */}
                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => moveNavLink(index, 'up')}
                    disabled={index === 0}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                    title="Move up"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                    </svg>
                  </button>
                  <button
                    onClick={() => moveNavLink(index, 'down')}
                    disabled={index === localSettings.navLinks.length - 1}
                    className="p-1 hover:bg-gray-100 rounded disabled:opacity-30 disabled:cursor-not-allowed"
                    title="Move down"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                </div>
                
                {/* Enabled toggle */}
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={link.enabled}
                    onChange={e => updateNavLink(index, 'enabled', e.target.checked)}
                    className="w-5 h-5 rounded accent-black"
                  />
                </label>
                
                {/* Label input */}
                <div className="flex-1">
                  <input
                    type="text"
                    value={link.label}
                    onChange={e => updateNavLink(index, 'label', e.target.value)}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none"
                    placeholder="Link label"
                  />
                </div>
                
                {/* Path input */}
                <div className="flex-1">
                  <input
                    type="text"
                    value={link.path}
                    onChange={e => updateNavLink(index, 'path', e.target.value)}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-black focus:outline-none font-mono text-sm"
                    placeholder="/page-url"
                  />
                </div>
                
                {/* Delete button */}
                <button
                  onClick={() => deleteNavLink(index)}
                  disabled={link.path === '/'}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                  title={link.path === '/' ? "Can't delete Home" : 'Delete link'}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
          
          {localSettings.navLinks.length === 0 && (
            <div className="text-center py-8 border-2 border-dashed rounded-lg">
              <p className="text-gray-500">No navigation links. Click "Add Link" to create one.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
