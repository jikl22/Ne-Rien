import { ArticleCard } from '../components/ArticleCard';
import { useArticles } from '../context/ArticleContext';
import { useSiteSettings } from '../context/SiteSettingsContext';
import { useTranslation } from '../context/TranslationContext';

interface HomePageProps {
  onArticleClick: (slug: string) => void;
  onCategoryClick: (category: string) => void;
}

export function HomePage({ onArticleClick, onCategoryClick }: HomePageProps) {
  const { articles, getFeaturedArticles, getLatestArticles } = useArticles();
  const { settings } = useSiteSettings();
  const { t } = useTranslation();
  const featuredArticles = getFeaturedArticles();
  const latestArticles = getLatestArticles(6);
  const mainFeatured = featuredArticles[0];
  const secondaryFeatured = featuredArticles[1];

  // Helper to get translated category name
  const getCategoryName = (categoryId: string) => {
    const key = categoryId.toLowerCase() as keyof typeof t;
    return t[key] || categoryId;
  };

  return (
    <main>
      {/* Hero Featured Article */}
      {mainFeatured && (
        <section className="mb-12">
          <ArticleCard
            article={mainFeatured}
            variant="featured"
            onClick={() => onArticleClick(mainFeatured.slug)}
          />
        </section>
      )}

      {/* Category Quick Links */}
      <section className="max-w-7xl mx-auto px-6 mb-16">
        <div className="flex flex-wrap justify-center gap-4">
          {settings.categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategoryClick(category.id)}
              className="px-6 py-2 border border-gray-200 text-sm uppercase tracking-wider hover:bg-black hover:text-white hover:border-black transition-all duration-300"
            >
              {getCategoryName(category.id)}
            </button>
          ))}
        </div>
      </section>

      {/* Latest Stories Grid */}
      <section className="max-w-7xl mx-auto px-6 mb-20">
        <div className="flex items-center justify-between mb-10">
          <h2 
            className="text-2xl lg:text-3xl font-serif font-bold"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {t.latestStories}
          </h2>
          <div className="h-px flex-1 bg-gray-200 ml-8 hidden md:block" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          {latestArticles.slice(0, 3).map((article) => (
            <ArticleCard
              key={article.id}
              article={article}
              onClick={() => onArticleClick(article.slug)}
            />
          ))}
        </div>
      </section>

      {/* Secondary Featured */}
      {secondaryFeatured && (
        <section className="bg-gray-50 py-16 mb-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={secondaryFeatured.image}
                  alt={secondaryFeatured.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer"
                  onClick={() => onArticleClick(secondaryFeatured.slug)}
                />
              </div>
              <div>
                <span className="inline-block px-3 py-1 bg-rose-100 text-rose-800 text-xs uppercase tracking-wider font-medium mb-4">
                  {secondaryFeatured.category}
                </span>
                <h2 
                  className="text-3xl lg:text-4xl font-serif font-bold leading-tight mb-4 cursor-pointer hover:underline decoration-2 underline-offset-4"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                  onClick={() => onArticleClick(secondaryFeatured.slug)}
                >
                  {secondaryFeatured.title}
                </h2>
                <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                  {secondaryFeatured.excerpt}
                </p>
                <div className="flex items-center gap-4">
                  <img
                    src={secondaryFeatured.authorImage}
                    alt={secondaryFeatured.author}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium">{secondaryFeatured.author}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(secondaryFeatured.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                      <span className="mx-2">•</span>
                      {secondaryFeatured.readTime} {t.minRead}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => onArticleClick(secondaryFeatured.slug)}
                  className="mt-8 px-8 py-3 bg-black text-white uppercase tracking-wider text-sm font-medium hover:bg-gray-800 transition-colors"
                >
                  {t.readMore}
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* More Stories */}
      <section className="max-w-7xl mx-auto px-6 mb-20">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Main column */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-8">
              <h2 
                className="text-2xl font-serif font-bold"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                {t.moreStories}
              </h2>
              <div className="h-px flex-1 bg-gray-200 ml-8" />
            </div>
            <div className="space-y-0">
              {articles.slice(3, 7).map((article) => (
                <ArticleCard
                  key={article.id}
                  article={article}
                  variant="horizontal"
                  onClick={() => onArticleClick(article.slug)}
                />
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <aside>
            <div className="sticky top-32">
              <div className="bg-black text-white p-8 mb-8">
                <h3 
                  className="text-xl font-serif font-bold mb-4"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {t.subscribe} - {settings.siteName}
                </h3>
                <p className="text-gray-400 text-sm mb-6">
                  {settings.newsletterSubtitle}
                </p>
                <input
                  type="email"
                  placeholder={t.emailPlaceholder}
                  className="w-full px-4 py-2 bg-white/10 border border-gray-600 focus:border-white focus:outline-none text-white placeholder-gray-500 mb-4"
                />
                <button className="w-full py-2 bg-white text-black font-medium uppercase tracking-wider text-sm hover:bg-gray-200 transition-colors">
                  {t.subscribe}
                </button>
              </div>

              <div>
                <h3 
                  className="text-lg font-serif font-bold mb-4 pb-2 border-b border-gray-200"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {t.trendingNow}
                </h3>
                {articles.slice(0, 4).map((article, index) => (
                  <div
                    key={article.id}
                    onClick={() => onArticleClick(article.slug)}
                    className="flex gap-4 py-4 border-b border-gray-100 last:border-0 cursor-pointer group"
                  >
                    <span className="text-3xl font-serif text-gray-200 font-bold">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                    <div>
                      <span className="text-xs uppercase tracking-wider text-gray-500">
                        {article.category}
                      </span>
                      <h4 
                        className="font-medium text-sm leading-snug group-hover:underline"
                        style={{ fontFamily: "'Playfair Display', serif" }}
                      >
                        {article.title}
                      </h4>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* Instagram Feed Placeholder */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 
            className="text-2xl lg:text-3xl font-serif font-bold mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Follow @ElanMagazine
          </h2>
          <p className="text-gray-600 mb-8">Join our community of fashion enthusiasts</p>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {[
              'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=300&h=300&fit=crop',
              'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=300&h=300&fit=crop',
              'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=300&h=300&fit=crop',
              'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=300&h=300&fit=crop',
              'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=300&h=300&fit=crop',
              'https://images.unsplash.com/photo-1558171813-4c088753af8f?w=300&h=300&fit=crop',
            ].map((src, index) => (
              <div key={index} className="aspect-square overflow-hidden group cursor-pointer">
                <img
                  src={src}
                  alt={`Instagram post ${index + 1}`}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
