import { useState, useEffect } from 'react';
import { ArticleCard } from '../components/ArticleCard';
import { Article } from '../data/articles';
import { useArticles } from '../context/ArticleContext';
import { useSiteSettings } from '../context/SiteSettingsContext';

interface SearchPageProps {
  query: string;
  onArticleClick: (slug: string) => void;
}

export function SearchPage({ query, onArticleClick }: SearchPageProps) {
  const { articles } = useArticles();
  const { settings } = useSiteSettings();
  const [results, setResults] = useState<Article[]>([]);
  const [searchInput, setSearchInput] = useState(query);

  useEffect(() => {
    const searchTerms = query.toLowerCase().split(' ');
    const filtered = articles.filter((article: Article) => {
      const searchableText = `${article.title} ${article.excerpt} ${article.category} ${article.author}`.toLowerCase();
      return searchTerms.some(term => searchableText.includes(term));
    });
    setResults(filtered);
    setSearchInput(query);
  }, [query, articles]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const searchTerms = searchInput.toLowerCase().split(' ');
    const filtered = articles.filter((article: Article) => {
      const searchableText = `${article.title} ${article.excerpt} ${article.category} ${article.author}`.toLowerCase();
      return searchTerms.some(term => searchableText.includes(term));
    });
    setResults(filtered);
  };

  return (
    <main className="pb-20">
      {/* Search Header */}
      <header className="bg-gray-50 py-16 mb-12">
        <div className="max-w-3xl mx-auto px-6">
          <h1 
            className="text-3xl lg:text-4xl font-serif font-bold mb-8 text-center"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Search {settings.siteName}
          </h1>
          <form onSubmit={handleSearch}>
            <div className="relative">
              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search articles, trends, designers..."
                className="w-full px-6 py-4 pr-14 border border-gray-300 focus:outline-none focus:border-black text-lg"
              />
              <button 
                type="submit" 
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </form>
        </div>
      </header>

      {/* Results */}
      <div className="max-w-7xl mx-auto px-6">
        {query && (
          <p className="text-gray-600 mb-8">
            {results.length} {results.length === 1 ? 'result' : 'results'} for "{query}"
          </p>
        )}

        {results.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
            {results.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                onClick={() => onArticleClick(article.slug)}
              />
            ))}
          </div>
        ) : query ? (
          <div className="text-center py-16">
            <svg className="w-16 h-16 mx-auto text-gray-300 mb-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <h2 
              className="text-2xl font-serif font-bold mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              No results found
            </h2>
            <p className="text-gray-600 max-w-md mx-auto">
              We couldn't find any articles matching "{query}". Try searching with different keywords.
            </p>
          </div>
        ) : (
          <div className="text-center py-16">
            <h2 
              className="text-2xl font-serif font-bold mb-4"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Discover Fashion Stories
            </h2>
            <p className="text-gray-600 max-w-md mx-auto">
              Search for articles about runway shows, trends, designers, celebrities, and more.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
