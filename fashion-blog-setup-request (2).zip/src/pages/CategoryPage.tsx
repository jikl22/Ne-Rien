import { ArticleCard } from '../components/ArticleCard';
import { useArticles } from '../context/ArticleContext';
import { useSiteSettings } from '../context/SiteSettingsContext';

interface CategoryPageProps {
  categoryId: string;
  onArticleClick: (slug: string) => void;
}

export function CategoryPage({ categoryId, onArticleClick }: CategoryPageProps) {
  const { getArticlesByCategory } = useArticles();
  const { settings } = useSiteSettings();
  const category = settings.categories.find(c => c.id === categoryId);
  const categoryArticles = getArticlesByCategory(categoryId);
  const featuredArticle = categoryArticles[0];
  const otherArticles = categoryArticles.slice(1);

  if (!category) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-20 text-center">
        <h1 className="text-3xl font-serif font-bold mb-4">Category not found</h1>
        <p className="text-gray-600">The category you're looking for doesn't exist.</p>
      </div>
    );
  }

  return (
    <main className="pb-20">
      {/* Category Header */}
      <header className="bg-black text-white py-16 lg:py-24 mb-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <span className="text-xs uppercase tracking-widest text-gray-400 mb-4 block">
            Category
          </span>
          <h1 
            className="text-4xl lg:text-6xl font-serif font-bold mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {category.name}
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            {category.description}
          </p>
        </div>
      </header>

      {/* Featured Article */}
      {featuredArticle && (
        <section className="max-w-7xl mx-auto px-6 mb-16">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={featuredArticle.image}
                alt={featuredArticle.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer"
                onClick={() => onArticleClick(featuredArticle.slug)}
              />
            </div>
            <div>
              <span className="text-xs uppercase tracking-widest text-gray-500 mb-4 block">
                Featured
              </span>
              <h2 
                className="text-2xl lg:text-4xl font-serif font-bold leading-tight mb-4 cursor-pointer hover:underline decoration-2 underline-offset-4"
                style={{ fontFamily: "'Playfair Display', serif" }}
                onClick={() => onArticleClick(featuredArticle.slug)}
              >
                {featuredArticle.title}
              </h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                {featuredArticle.excerpt}
              </p>
              <div className="flex items-center gap-4 mb-6">
                <img
                  src={featuredArticle.authorImage}
                  alt={featuredArticle.author}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div className="text-sm">
                  <p className="font-medium">{featuredArticle.author}</p>
                  <p className="text-gray-500">
                    {new Date(featuredArticle.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                    <span className="mx-2">•</span>
                    {featuredArticle.readTime}
                  </p>
                </div>
              </div>
              <button
                onClick={() => onArticleClick(featuredArticle.slug)}
                className="px-8 py-3 bg-black text-white uppercase tracking-wider text-sm font-medium hover:bg-gray-800 transition-colors"
              >
                Read Article
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Articles Grid */}
      {otherArticles.length > 0 && (
        <section className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between mb-10">
            <h2 
              className="text-2xl font-serif font-bold"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              All {category.name} Articles
            </h2>
            <div className="h-px flex-1 bg-gray-200 ml-8 hidden md:block" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
            {otherArticles.map((article) => (
              <ArticleCard
                key={article.id}
                article={article}
                onClick={() => onArticleClick(article.slug)}
              />
            ))}
          </div>
        </section>
      )}

      {categoryArticles.length === 0 && (
        <div className="max-w-7xl mx-auto px-6 py-20 text-center">
          <p className="text-gray-600 text-lg">No articles found in this category yet.</p>
        </div>
      )}
    </main>
  );
}
