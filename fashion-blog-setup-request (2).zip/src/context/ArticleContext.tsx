import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { articles as initialArticles, Article } from '../data/articles';

interface ArticleContextType {
  articles: Article[];
  addArticle: (article: Omit<Article, 'id'>) => void;
  updateArticle: (id: string, article: Partial<Article>) => void;
  deleteArticle: (id: string) => void;
  getArticleBySlug: (slug: string) => Article | undefined;
  getArticlesByCategory: (category: string) => Article[];
  getFeaturedArticles: () => Article[];
  getLatestArticles: (count?: number) => Article[];
}

const ArticleContext = createContext<ArticleContextType | undefined>(undefined);

const STORAGE_KEY = 'nerien_articles';

export function ArticleProvider({ children }: { children: ReactNode }) {
  const [articles, setArticles] = useState<Article[]>(() => {
    // Try to load from localStorage first
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        return initialArticles;
      }
    }
    return initialArticles;
  });

  // Save to localStorage whenever articles change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
  }, [articles]);

  const addArticle = (article: Omit<Article, 'id'>) => {
    const newArticle: Article = {
      ...article,
      id: Date.now().toString(),
    };
    setArticles(prev => [newArticle, ...prev]);
  };

  const updateArticle = (id: string, updates: Partial<Article>) => {
    setArticles(prev => 
      prev.map(article => 
        article.id === id ? { ...article, ...updates } : article
      )
    );
  };

  const deleteArticle = (id: string) => {
    setArticles(prev => prev.filter(article => article.id !== id));
  };

  const getArticleBySlug = (slug: string) => {
    return articles.find(article => article.slug === slug);
  };

  const getArticlesByCategory = (category: string) => {
    return articles.filter(article => article.category === category);
  };

  const getFeaturedArticles = () => {
    return articles.filter(article => article.featured);
  };

  const getLatestArticles = (count: number = 6) => {
    return [...articles]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, count);
  };

  return (
    <ArticleContext.Provider value={{
      articles,
      addArticle,
      updateArticle,
      deleteArticle,
      getArticleBySlug,
      getArticlesByCategory,
      getFeaturedArticles,
      getLatestArticles,
    }}>
      {children}
    </ArticleContext.Provider>
  );
}

export function useArticles() {
  const context = useContext(ArticleContext);
  if (!context) {
    throw new Error('useArticles must be used within an ArticleProvider');
  }
  return context;
}
