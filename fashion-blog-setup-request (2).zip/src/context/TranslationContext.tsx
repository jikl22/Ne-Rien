import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'es';

interface Translations {
  // Navigation
  home: string;
  search: string;
  admin: string;
  newsletter: string;
  subscribe: string;
  
  // Categories
  runway: string;
  trends: string;
  culture: string;
  celebrity: string;
  beauty: string;
  news: string;
  
  // Homepage
  latestStories: string;
  featuredStory: string;
  trendingNow: string;
  readMore: string;
  minRead: string;
  viewAll: string;
  moreStories: string;
  
  // Newsletter
  newsletterTitle: string;
  newsletterSubtitle: string;
  emailPlaceholder: string;
  subscribeButton: string;
  subscribing: string;
  thankYou: string;
  
  // Article
    shareArticle: string;
    share: string;
    copyLink: string;
    linkCopied: string;
    tags: string;
    relatedArticles: string;
    moreIn: string;
    about: string;
    viewAllBy: string;
    by: string;
  
  // Search
  searchPlaceholder: string;
  searchResultsFor: string;
  noResultsFound: string;
  tryDifferentKeywords: string;
  articlesFound: string;
  
  // Footer
  aboutUs: string;
  quickLinks: string;
  followUs: string;
  allRightsReserved: string;
  
  // Admin
  adminPanel: string;
  login: string;
  logout: string;
  password: string;
  enterPassword: string;
  invalidPassword: string;
  dashboard: string;
  articles: string;
  newArticle: string;
  editArticle: string;
  deleteArticle: string;
  siteSettings: string;
  settings: string;
  save: string;
  cancel: string;
  saveChanges: string;
  saving: string;
  saved: string;
  confirmDelete: string;
  yes: string;
  no: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  authorPhoto: string;
  featuredImage: string;
  publishDate: string;
  readTime: string;
  featured: string;
  actions: string;
  edit: string;
  delete: string;
  preview: string;
  backToDashboard: string;
  
  // Site Settings
  branding: string;
  seo: string;
  contentSettings: string;
  social: string;
  categories: string;
  navigation: string;
  siteName: string;
  logoText: string;
  tagline: string;
  siteDescription: string;
  footerCopyright: string;
  footerAbout: string;
  seoTitle: string;
  seoDescription: string;
  keywords: string;
  heroTitle: string;
  heroSubtitle: string;
  contactEmail: string;
  contactAddress: string;
  
  // Spanish content
  spanishContent: string;
  spanishTitle: string;
  spanishExcerpt: string;
  spanishContentLabel: string;
  optional: string;
  
  // Language
  language: string;
  english: string;
  spanish: string;
}

const translations: Record<Language, Translations> = {
  en: {
    // Navigation
    home: 'Home',
    search: 'Search',
    admin: 'Admin',
    newsletter: 'Newsletter',
    subscribe: 'Subscribe',
    
    // Categories
    runway: 'Runway',
    trends: 'Trends',
    culture: 'Culture',
    celebrity: 'Celebrity',
    beauty: 'Beauty',
    news: 'News',
    
    // Homepage
    latestStories: 'Latest Stories',
    featuredStory: 'Featured Story',
    trendingNow: 'Trending Now',
    readMore: 'Read More',
    minRead: 'min read',
    viewAll: 'View All',
    moreStories: 'More Stories',
    
    // Newsletter
    newsletterTitle: 'Stay in Style',
    newsletterSubtitle: 'Subscribe to our newsletter for the latest fashion insights',
    emailPlaceholder: 'Enter your email',
    subscribeButton: 'Subscribe',
    subscribing: 'Subscribing...',
    thankYou: 'Thank you for subscribing!',
    
    // Article
    shareArticle: 'Share this article',
    share: 'Share',
    copyLink: 'Copy Link',
    linkCopied: 'Link copied!',
    tags: 'Tags',
    relatedArticles: 'Related Articles',
    moreIn: 'More in',
    about: 'About',
    viewAllBy: 'View all articles by',
    by: 'By',
    
    // Search
    searchPlaceholder: 'Search articles...',
    searchResultsFor: 'Search results for',
    noResultsFound: 'No articles found',
    tryDifferentKeywords: 'Try different keywords or browse our categories',
    articlesFound: 'articles found',
    
    // Footer
    aboutUs: 'About Us',
    quickLinks: 'Quick Links',
    followUs: 'Follow Us',
    allRightsReserved: 'All rights reserved',
    
    // Admin
    adminPanel: 'Admin Panel',
    login: 'Login',
    logout: 'Logout',
    password: 'Password',
    enterPassword: 'Enter password',
    invalidPassword: 'Invalid password',
    dashboard: 'Dashboard',
    articles: 'Articles',
    newArticle: 'New Article',
    editArticle: 'Edit Article',
    deleteArticle: 'Delete Article',
    siteSettings: 'Site Settings',
    settings: 'Settings',
    save: 'Save',
    cancel: 'Cancel',
    saveChanges: 'Save Changes',
    saving: 'Saving...',
    saved: 'Saved!',
    confirmDelete: 'Are you sure you want to delete this?',
    yes: 'Yes',
    no: 'No',
    title: 'Title',
    excerpt: 'Excerpt',
    content: 'Content',
    category: 'Category',
    author: 'Author',
    authorPhoto: 'Author Photo URL',
    featuredImage: 'Featured Image URL',
    publishDate: 'Publish Date',
    readTime: 'Read Time',
    featured: 'Featured',
    actions: 'Actions',
    edit: 'Edit',
    delete: 'Delete',
    preview: 'Preview',
    backToDashboard: 'Back to Dashboard',
    
    // Site Settings
    branding: 'Branding',
    seo: 'SEO',
    contentSettings: 'Content',
    social: 'Social',
    categories: 'Categories',
    navigation: 'Navigation',
    siteName: 'Site Name',
    logoText: 'Logo Text',
    tagline: 'Tagline',
    siteDescription: 'Site Description',
    footerCopyright: 'Footer Copyright',
    footerAbout: 'Footer About Text',
    seoTitle: 'SEO Title',
    seoDescription: 'SEO Description',
    keywords: 'Keywords',
    heroTitle: 'Hero Title',
    heroSubtitle: 'Hero Subtitle',
    contactEmail: 'Contact Email',
    contactAddress: 'Contact Address',
    
    // Spanish content
    spanishContent: 'Spanish Content',
    spanishTitle: 'Spanish Title',
    spanishExcerpt: 'Spanish Excerpt',
    spanishContentLabel: 'Spanish Content',
    optional: 'Optional',
    
    // Language
    language: 'Language',
    english: 'English',
    spanish: 'Spanish',
  },
  es: {
    // Navigation
    home: 'Inicio',
    search: 'Buscar',
    admin: 'Admin',
    newsletter: 'Boletín',
    subscribe: 'Suscribirse',
    
    // Categories
    runway: 'Pasarela',
    trends: 'Tendencias',
    culture: 'Cultura',
    celebrity: 'Celebridades',
    beauty: 'Belleza',
    news: 'Noticias',
    
    // Homepage
    latestStories: 'Últimas Historias',
    featuredStory: 'Historia Destacada',
    trendingNow: 'Tendencias',
    readMore: 'Leer Más',
    minRead: 'min de lectura',
    viewAll: 'Ver Todo',
    moreStories: 'Más Historias',
    
    // Newsletter
    newsletterTitle: 'Mantente al Día',
    newsletterSubtitle: 'Suscríbete a nuestro boletín para las últimas tendencias',
    emailPlaceholder: 'Ingresa tu email',
    subscribeButton: 'Suscribirse',
    subscribing: 'Suscribiendo...',
    thankYou: '¡Gracias por suscribirte!',
    
    // Article
    shareArticle: 'Compartir este artículo',
    share: 'Compartir',
    copyLink: 'Copiar Enlace',
    linkCopied: '¡Enlace copiado!',
    tags: 'Etiquetas',
    relatedArticles: 'Artículos Relacionados',
    moreIn: 'Más en',
    about: 'Sobre',
    viewAllBy: 'Ver todos los artículos de',
    by: 'Por',
    
    // Search
    searchPlaceholder: 'Buscar artículos...',
    searchResultsFor: 'Resultados de búsqueda para',
    noResultsFound: 'No se encontraron artículos',
    tryDifferentKeywords: 'Intenta con otras palabras o explora nuestras categorías',
    articlesFound: 'artículos encontrados',
    
    // Footer
    aboutUs: 'Sobre Nosotros',
    quickLinks: 'Enlaces Rápidos',
    followUs: 'Síguenos',
    allRightsReserved: 'Todos los derechos reservados',
    
    // Admin
    adminPanel: 'Panel de Admin',
    login: 'Iniciar Sesión',
    logout: 'Cerrar Sesión',
    password: 'Contraseña',
    enterPassword: 'Ingresa la contraseña',
    invalidPassword: 'Contraseña incorrecta',
    dashboard: 'Panel',
    articles: 'Artículos',
    newArticle: 'Nuevo Artículo',
    editArticle: 'Editar Artículo',
    deleteArticle: 'Eliminar Artículo',
    siteSettings: 'Configuración del Sitio',
    settings: 'Configuración',
    save: 'Guardar',
    cancel: 'Cancelar',
    saveChanges: 'Guardar Cambios',
    saving: 'Guardando...',
    saved: '¡Guardado!',
    confirmDelete: '¿Estás seguro de que quieres eliminar esto?',
    yes: 'Sí',
    no: 'No',
    title: 'Título',
    excerpt: 'Extracto',
    content: 'Contenido',
    category: 'Categoría',
    author: 'Autor',
    authorPhoto: 'URL de Foto del Autor',
    featuredImage: 'URL de Imagen Destacada',
    publishDate: 'Fecha de Publicación',
    readTime: 'Tiempo de Lectura',
    featured: 'Destacado',
    actions: 'Acciones',
    edit: 'Editar',
    delete: 'Eliminar',
    preview: 'Vista Previa',
    backToDashboard: 'Volver al Panel',
    
    // Site Settings
    branding: 'Marca',
    seo: 'SEO',
    contentSettings: 'Contenido',
    social: 'Redes Sociales',
    categories: 'Categorías',
    navigation: 'Navegación',
    siteName: 'Nombre del Sitio',
    logoText: 'Texto del Logo',
    tagline: 'Eslogan',
    siteDescription: 'Descripción del Sitio',
    footerCopyright: 'Copyright del Pie',
    footerAbout: 'Texto Sobre Nosotros',
    seoTitle: 'Título SEO',
    seoDescription: 'Descripción SEO',
    keywords: 'Palabras Clave',
    heroTitle: 'Título Principal',
    heroSubtitle: 'Subtítulo Principal',
    contactEmail: 'Email de Contacto',
    contactAddress: 'Dirección de Contacto',
    
    // Spanish content
    spanishContent: 'Contenido en Español',
    spanishTitle: 'Título en Español',
    spanishExcerpt: 'Extracto en Español',
    spanishContentLabel: 'Contenido en Español',
    optional: 'Opcional',
    
    // Language
    language: 'Idioma',
    english: 'Inglés',
    spanish: 'Español',
  }
};

interface TranslationContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export function TranslationProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
    document.documentElement.lang = language;
  }, [language]);

  const t = translations[language];

  return (
    <TranslationContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </TranslationContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}
