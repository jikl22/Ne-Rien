import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  login: (password: string) => boolean;
  logout: () => void;
  changePassword: (currentPassword: string, newPassword: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_KEY = 'nerien_auth_v1';
const PASSWORD_KEY = 'nerien_admin_password_v1';
const DEFAULT_PASSWORD = 'nerien2024'; // Default password - users should change this!

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    const stored = localStorage.getItem(AUTH_KEY);
    return stored === 'true';
  });

  useEffect(() => {
    localStorage.setItem(AUTH_KEY, String(isAuthenticated));
  }, [isAuthenticated]);

  const getStoredPassword = () => {
    return localStorage.getItem(PASSWORD_KEY) || DEFAULT_PASSWORD;
  };

  const login = (password: string) => {
    const storedPassword = getStoredPassword();
    if (password === storedPassword) {
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem(AUTH_KEY);
  };

  const changePassword = (currentPassword: string, newPassword: string) => {
    const storedPassword = getStoredPassword();
    if (currentPassword === storedPassword && newPassword.length >= 4) {
      localStorage.setItem(PASSWORD_KEY, newPassword);
      return true;
    }
    return false;
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout, changePassword }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
