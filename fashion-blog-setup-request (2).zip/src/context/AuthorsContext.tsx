import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Author {
  id: string;
  name: string;
  photo: string;
  role: string;
  bio: string;
  email?: string;
  instagram?: string;
  twitter?: string;
  website?: string;
}

interface AuthorsContextType {
  authors: Author[];
  addAuthor: (author: Omit<Author, 'id'>) => void;
  updateAuthor: (id: string, author: Partial<Author>) => void;
  deleteAuthor: (id: string) => void;
  getAuthorById: (id: string) => Author | undefined;
  getAuthorByName: (name: string) => Author | undefined;
}

const defaultAuthors: Author[] = [
  {
    id: 'author-1',
    name: 'Isabella Chen',
    photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    role: 'Fashion Director',
    bio: 'Isabella Chen is our Fashion Director with over 15 years of experience covering haute couture and emerging designers. She has worked with Vogue Paris and Harper\'s Bazaar before joining NE RIEN.',
    email: 'isabella@nerien.com',
    instagram: 'https://instagram.com/isabellachen',
    twitter: 'https://twitter.com/isabellachen'
  },
  {
    id: 'author-2',
    name: 'Marcus Webb',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    role: 'Style Editor',
    bio: 'Marcus Webb brings his unique perspective on men\'s fashion and street style. A graduate of Central Saint Martins, he has an eye for emerging trends.',
    email: 'marcus@nerien.com',
    instagram: 'https://instagram.com/marcuswebb'
  },
  {
    id: 'author-3',
    name: 'Sofia Martinez',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
    role: 'Beauty Editor',
    bio: 'Sofia Martinez covers all things beauty, from skincare innovations to makeup trends. She previously worked at Allure and Elle.',
    email: 'sofia@nerien.com',
    instagram: 'https://instagram.com/sofiamartinez'
  },
  {
    id: 'author-4',
    name: 'James Morrison',
    photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
    role: 'Culture Correspondent',
    bio: 'James Morrison explores the intersection of fashion and culture, covering everything from art exhibitions to celebrity style.',
    email: 'james@nerien.com',
    twitter: 'https://twitter.com/jamesmorrison'
  },
  {
    id: 'author-5',
    name: 'Elena Rossi',
    photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    role: 'Sustainability Editor',
    bio: 'Elena Rossi is passionate about sustainable fashion and ethical practices in the industry. She leads our coverage on eco-conscious fashion.',
    email: 'elena@nerien.com',
    website: 'https://elenarossi.com'
  }
];

const AuthorsContext = createContext<AuthorsContextType | undefined>(undefined);

export const AuthorsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [authors, setAuthors] = useState<Author[]>(() => {
    const saved = localStorage.getItem('nerien-authors-v2');
    return saved ? JSON.parse(saved) : defaultAuthors;
  });

  useEffect(() => {
    localStorage.setItem('nerien-authors-v2', JSON.stringify(authors));
  }, [authors]);

  const addAuthor = (author: Omit<Author, 'id'>) => {
    const newAuthor: Author = {
      ...author,
      id: `author-${Date.now()}`
    };
    setAuthors(prev => [...prev, newAuthor]);
  };

  const updateAuthor = (id: string, updates: Partial<Author>) => {
    setAuthors(prev => prev.map(author => 
      author.id === id ? { ...author, ...updates } : author
    ));
  };

  const deleteAuthor = (id: string) => {
    setAuthors(prev => prev.filter(author => author.id !== id));
  };

  const getAuthorById = (id: string) => {
    return authors.find(author => author.id === id);
  };

  const getAuthorByName = (name: string) => {
    return authors.find(author => author.name.toLowerCase() === name.toLowerCase());
  };

  return (
    <AuthorsContext.Provider value={{
      authors,
      addAuthor,
      updateAuthor,
      deleteAuthor,
      getAuthorById,
      getAuthorByName
    }}>
      {children}
    </AuthorsContext.Provider>
  );
};

export const useAuthors = () => {
  const context = useContext(AuthorsContext);
  if (!context) {
    throw new Error('useAuthors must be used within an AuthorsProvider');
  }
  return context;
};
