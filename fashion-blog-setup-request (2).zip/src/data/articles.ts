export interface Article {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: 'runway' | 'trends' | 'culture' | 'celebrity' | 'beauty' | 'news';
  author: string;
  authorImage: string;
  date: string;
  image: string;
  featured?: boolean;
  readTime: string;
  // Spanish translations (optional)
  titleEs?: string;
  excerptEs?: string;
  contentEs?: string;
}

export const articles: Article[] = [
  {
    id: '1',
    slug: 'paris-fashion-week-spring-2025',
    title: 'Paris Fashion Week Spring 2025: The Definitive Runway Report',
    excerpt: 'From Dior\'s romantic garden party to Chanel\'s bold architectural statements, we break down the most influential collections of the season.',
    content: `
      <p>Paris Fashion Week has once again cemented its position as the pinnacle of haute couture, delivering collections that will shape the fashion landscape for seasons to come.</p>
      
      <h2>Dior: A Garden of Earthly Delights</h2>
      <p>Maria Grazia Chiuri transported guests to an ethereal garden, where flowing silhouettes met intricate embroidery. The collection celebrated femininity in all its forms, with structured bodices giving way to billowing skirts adorned with hand-painted florals.</p>
      
      <h2>Chanel: Architectural Dreams</h2>
      <p>Virginie Viard took a bold departure from tradition, presenting geometric shapes and stark contrasts. Black and white dominated, punctuated by flashes of vermillion red. The iconic tweed was reimagined in deconstructed forms that felt both revolutionary and respectfully nostalgic.</p>
      
      <h2>Saint Laurent: After Dark</h2>
      <p>Anthony Vaccarello's collection was a love letter to the night. Sleek tailoring, plunging necklines, and strategic cutouts created silhouettes that commanded attention. Velvet and leather intertwined in pieces that whispered of mystery and allure.</p>
      
      <h2>The Takeaway</h2>
      <p>This season's Paris Fashion Week reminded us why the city remains fashion's beating heart. As we look ahead to spring, expect to see romantic florals, bold geometrics, and a renewed appreciation for masterful tailoring.</p>
    `,
    category: 'runway',
    author: 'Isabella Fontaine',
    authorImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
    date: '2024-12-15',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200',
    featured: true,
    readTime: '8 min'
  },
  {
    id: '2',
    slug: 'quiet-luxury-revolution',
    title: 'The Quiet Luxury Revolution: Why Less Is Finally More',
    excerpt: 'The era of logo-heavy fashion is fading. Discover why discerning fashion enthusiasts are embracing understated elegance.',
    content: `
      <p>In an age of constant visual noise, a new aesthetic movement is gaining momentum. Quiet luxury—characterized by impeccable craftsmanship, premium materials, and the deliberate absence of visible branding—is reshaping how we think about fashion.</p>
      
      <h2>The Psychology Behind the Shift</h2>
      <p>After years of maximalism and logo-centric dressing, consumers are seeking authenticity. There's a growing desire to invest in pieces that speak through quality rather than quantity, that whisper rather than shout.</p>
      
      <h2>Key Players in the Movement</h2>
      <p>Brands like The Row, Loro Piana, and Brunello Cucinelli have long championed this aesthetic. Now, even traditionally logo-heavy houses are creating more subdued offerings, recognizing the shift in consumer preferences.</p>
      
      <h2>Building Your Quiet Luxury Wardrobe</h2>
      <p>Focus on timeless silhouettes, invest in natural fabrics, and prioritize fit above all else. A perfectly tailored cashmere coat speaks louder than any logo ever could.</p>
    `,
    category: 'trends',
    author: 'Marcus Chen',
    authorImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
    date: '2024-12-12',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200',
    featured: true,
    readTime: '6 min'
  },
  {
    id: '3',
    slug: 'zendaya-met-gala-moments',
    title: 'Zendaya\'s Most Iconic Met Gala Moments: A Fashion Retrospective',
    excerpt: 'From her Cinderella moment to her avant-garde Joan of Arc transformation, we celebrate Zendaya\'s reign as fashion\'s fearless muse.',
    content: `
      <p>When it comes to red carpet fashion, few celebrities command attention quite like Zendaya. Her Met Gala appearances have become the stuff of legend, each one more breathtaking than the last.</p>
      
      <h2>The Cinderella Moment (2019)</h2>
      <p>In collaboration with stylist Law Roach and designer Tommy Hilfiger, Zendaya arrived in a color-changing gown that literally lit up as her fairy godfather waved his wand. It was fashion as performance art, cementing her status as a red carpet risk-taker.</p>
      
      <h2>Joan of Arc Rises (2018)</h2>
      <p>Dressed in custom Versace chainmail, Zendaya channeled the warrior saint with fierce elegance. The look proved that historical references could feel thoroughly modern when executed with confidence and vision.</p>
      
      <h2>The Legacy Continues</h2>
      <p>Each appearance adds another chapter to Zendaya's fashion story—one defined by boldness, creativity, and an unwavering commitment to pushing boundaries.</p>
    `,
    category: 'celebrity',
    author: 'Aria Williams',
    authorImage: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
    date: '2024-12-10',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1200',
    readTime: '5 min'
  },
  {
    id: '4',
    slug: 'sustainable-fashion-future',
    title: 'The Future Is Circular: How Fashion Is Embracing Sustainability',
    excerpt: 'From recycled materials to rental models, the fashion industry is undergoing a green revolution. Here\'s what you need to know.',
    content: `
      <p>The fashion industry, long criticized for its environmental impact, is undergoing a fundamental transformation. Sustainability is no longer a niche concern—it's becoming the new standard.</p>
      
      <h2>The Rise of Circular Fashion</h2>
      <p>Leading brands are reimagining the entire lifecycle of garments. Take-back programs, recycling initiatives, and designs intended for disassembly are becoming commonplace.</p>
      
      <h2>Material Innovations</h2>
      <p>From mushroom leather to ocean plastic, designers are exploring revolutionary materials that minimize environmental impact without sacrificing aesthetics or durability.</p>
      
      <h2>The Consumer's Role</h2>
      <p>Ultimately, sustainable fashion requires informed consumers. By choosing quality over quantity and supporting responsible brands, we all play a part in fashion's green future.</p>
    `,
    category: 'culture',
    author: 'Elena Rodriguez',
    authorImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
    date: '2024-12-08',
    image: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=1200',
    readTime: '7 min'
  },
  {
    id: '5',
    slug: 'spring-beauty-trends-2025',
    title: 'Spring 2025 Beauty Trends: The Looks You\'ll See Everywhere',
    excerpt: 'Glazed skin, bold brows, and unexpected color play define the beauty landscape this season.',
    content: `
      <p>As the runways have spoken, so shall the streets follow. Spring 2025 brings a refreshing mix of natural radiance and bold experimentation to the beauty world.</p>
      
      <h2>The Glass Skin Revolution</h2>
      <p>Dewy, luminous skin remains paramount. The goal is skin so healthy it appears to glow from within—achieved through meticulous skincare and strategic highlighting.</p>
      
      <h2>Brows Take Center Stage</h2>
      <p>Full, feathered, and unapologetically bold—brows are the focal point. Laminating treatments and growth serums are seeing unprecedented demand.</p>
      
      <h2>Color Play</h2>
      <p>From electric blue eyeliner to terracotta lips, this season encourages experimentation. The key is one statement element paired with understated elegance elsewhere.</p>
    `,
    category: 'beauty',
    author: 'Sophie Laurent',
    authorImage: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100',
    date: '2024-12-05',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=1200',
    readTime: '4 min'
  },
  {
    id: '6',
    slug: 'gucci-new-creative-director',
    title: 'Breaking: Gucci Announces Surprise Creative Director Appointment',
    excerpt: 'The Italian house makes a bold move, tapping an unexpected talent to lead its next chapter.',
    content: `
      <p>In a move that has sent shockwaves through the fashion industry, Gucci has announced the appointment of a new creative director—a decision that signals a new era for the storied Italian house.</p>
      
      <h2>A Bold New Direction</h2>
      <p>The appointment represents a departure from recent strategies, suggesting Gucci is ready to take risks and challenge expectations once again.</p>
      
      <h2>Industry Reaction</h2>
      <p>Fashion insiders have responded with a mix of excitement and curiosity. The consensus: this is a brand willing to evolve while honoring its rich heritage.</p>
      
      <h2>What's Next</h2>
      <p>All eyes will be on the first collection, expected to debut during Milan Fashion Week. The fashion world waits with bated breath.</p>
    `,
    category: 'news',
    author: 'James Morrison',
    authorImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100',
    date: '2024-12-03',
    image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200',
    readTime: '3 min'
  },
  {
    id: '7',
    slug: 'vintage-fashion-investment',
    title: 'Vintage Fashion as Investment: What to Buy Now',
    excerpt: 'From Hermès Birkins to vintage Chanel, discover which pieces are appreciating in value.',
    content: `
      <p>In an era of fast fashion, vintage pieces offer something increasingly rare: uniqueness, quality, and potential financial returns. Here's your guide to collecting fashion as an investment.</p>
      
      <h2>The Blue Chips</h2>
      <p>Hermès bags, particularly Birkins and Kellys, consistently outperform traditional investments. Rare colors and exotic leathers command premium prices at auction.</p>
      
      <h2>Rising Stars</h2>
      <p>Early Phoebe Philo-era Céline, vintage Alaïa, and archival Maison Margiela are seeing increased collector interest.</p>
      
      <h2>Authentication Is Key</h2>
      <p>With values rising, so do counterfeits. Always purchase from reputable sources and invest in professional authentication.</p>
    `,
    category: 'culture',
    author: 'Victoria Hayes',
    authorImage: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100',
    date: '2024-12-01',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200',
    readTime: '6 min'
  },
  {
    id: '8',
    slug: 'milan-fashion-week-highlights',
    title: 'Milan Fashion Week: Maximalism Returns in Full Force',
    excerpt: 'Italian designers embrace bold colors, lavish embellishments, and unapologetic glamour.',
    content: `
      <p>If Paris whispered quiet luxury, Milan shouted maximalist joy. The Italian fashion capital delivered collections bursting with color, texture, and unbridled creativity.</p>
      
      <h2>Dolce & Gabbana: Sicilian Dreams</h2>
      <p>The duo returned to their roots with a celebration of Sicilian craftsmanship. Hand-painted ceramics, intricate lacework, and sun-drenched colors dominated.</p>
      
      <h2>Prada: Intellectual Glamour</h2>
      <p>Miuccia Prada and Raf Simons continued their exploration of beauty and meaning, presenting pieces that challenged and delighted in equal measure.</p>
      
      <h2>Versace: Unbridled Power</h2>
      <p>Donatella delivered a collection celebrating strength and sensuality, with bold prints and daring silhouettes that commanded every room.</p>
    `,
    category: 'runway',
    author: 'Isabella Fontaine',
    authorImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
    date: '2024-11-28',
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1200',
    readTime: '7 min'
  }
];

export const categories = [
  { id: 'runway', name: 'Runway', description: 'The latest from fashion weeks around the world' },
  { id: 'trends', name: 'Trends', description: 'What\'s in and what\'s next' },
  { id: 'culture', name: 'Culture', description: 'Fashion\'s intersection with art, society, and life' },
  { id: 'celebrity', name: 'Celebrity', description: 'Red carpet moments and star style' },
  { id: 'beauty', name: 'Beauty', description: 'Makeup, skincare, and self-care' },
  { id: 'news', name: 'News', description: 'Breaking stories from the fashion world' }
];

export function getArticleBySlug(slug: string): Article | undefined {
  return articles.find(article => article.slug === slug);
}

export function getArticlesByCategory(category: string): Article[] {
  return articles.filter(article => article.category === category);
}

export function getFeaturedArticles(): Article[] {
  return articles.filter(article => article.featured);
}

export function getLatestArticles(count: number = 6): Article[] {
  return [...articles].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, count);
}
