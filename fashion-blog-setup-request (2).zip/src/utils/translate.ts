// Translation utility using MyMemory API (free, no API key needed)
// Limit: 1000 chars per request, 10000 chars per day

export async function translateText(text: string, from: 'en' | 'es', to: 'en' | 'es'): Promise<string> {
  if (!text.trim()) return '';
  
  // Split long text into chunks of 500 chars (to stay under limit)
  const chunks = splitIntoChunks(text, 500);
  const translatedChunks: string[] = [];
  
  for (const chunk of chunks) {
    try {
      const response = await fetch(
        `https://api.mymemory.translated.net/get?q=${encodeURIComponent(chunk)}&langpair=${from}|${to}`
      );
      
      if (!response.ok) {
        throw new Error('Translation failed');
      }
      
      const data = await response.json();
      
      if (data.responseStatus === 200) {
        translatedChunks.push(data.responseData.translatedText);
      } else {
        throw new Error(data.responseDetails || 'Translation failed');
      }
    } catch (error) {
      console.error('Translation error:', error);
      // Return original text if translation fails
      translatedChunks.push(chunk);
    }
  }
  
  return translatedChunks.join(' ');
}

function splitIntoChunks(text: string, maxLength: number): string[] {
  const chunks: string[] = [];
  let remaining = text;
  
  while (remaining.length > 0) {
    if (remaining.length <= maxLength) {
      chunks.push(remaining);
      break;
    }
    
    // Find a good break point (end of sentence or paragraph)
    let breakPoint = maxLength;
    const lastPeriod = remaining.lastIndexOf('.', maxLength);
    const lastNewline = remaining.lastIndexOf('\n', maxLength);
    const lastSpace = remaining.lastIndexOf(' ', maxLength);
    
    if (lastPeriod > maxLength * 0.5) {
      breakPoint = lastPeriod + 1;
    } else if (lastNewline > maxLength * 0.5) {
      breakPoint = lastNewline + 1;
    } else if (lastSpace > maxLength * 0.5) {
      breakPoint = lastSpace + 1;
    }
    
    chunks.push(remaining.substring(0, breakPoint));
    remaining = remaining.substring(breakPoint).trim();
  }
  
  return chunks;
}

// Translate HTML content while preserving tags
export async function translateHTML(html: string, from: 'en' | 'es', to: 'en' | 'es'): Promise<string> {
  // Simple approach: translate text between tags
  // This preserves HTML structure while translating content
  
  const tagRegex = /(<[^>]+>)/g;
  const parts = html.split(tagRegex);
  
  const translatedParts: string[] = [];
  
  for (const part of parts) {
    if (part.startsWith('<')) {
      // It's a tag, keep it as is
      translatedParts.push(part);
    } else if (part.trim()) {
      // It's text content, translate it
      const translated = await translateText(part, from, to);
      translatedParts.push(translated);
    } else {
      // Empty or whitespace, keep as is
      translatedParts.push(part);
    }
  }
  
  return translatedParts.join('');
}
