import { Article } from '../data/articles';
import { downloadFile } from './markdownMirror';

const BASE_URL = 'https://nerien.netlify.app';

const CATEGORIES = [
  'runway', 'trends', 'culture', 'celebrity', 'beauty', 'news', 'mexico'
];

function xmlEscape(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function formatDate(dateStr: string): string {
  try {
    return new Date(dateStr).toISOString().split('T')[0];
  } catch {
    return new Date().toISOString().split('T')[0];
  }
}

// ─── Main sitemap (homepage + categories + articles) ─────────────────────────
export function generateSitemap(articles: Article[]): string {
  const today = new Date().toISOString().split('T')[0];

  const homepageUrl = `
  <url>
    <loc>${BASE_URL}/</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`;

  const categoryUrls = CATEGORIES.map(cat => `
  <url>
    <loc>${BASE_URL}/category/${cat}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>`).join('');

  const articleUrls = articles.map(article => {
    const lastmod = formatDate(article.date);
    const imageTag = article.image ? `
    <image:image>
      <image:loc>${xmlEscape(article.image.split('?')[0])}</image:loc>
      <image:title>${xmlEscape(article.title)}</image:title>
      <image:caption>${xmlEscape(article.excerpt.slice(0, 100))}</image:caption>
    </image:image>` : '';

    const newsTag = `
    <news:news>
      <news:publication>
        <news:name>NE RIEN Magazine</news:name>
        <news:language>en</news:language>
      </news:publication>
      <news:publication_date>${lastmod}</news:publication_date>
      <news:title>${xmlEscape(article.title)}</news:title>
      <news:keywords>${xmlEscape(article.category)}</news:keywords>
    </news:news>`;

    return `
  <url>
    <loc>${BASE_URL}/article/${article.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>${imageTag}${newsTag}
    <xhtml:link rel="alternate" hreflang="en" href="${BASE_URL}/article/${article.slug}"/>
    <xhtml:link rel="alternate" hreflang="x-default" href="${BASE_URL}/article/${article.slug}"/>
  </url>`;
  }).join('');

  const mirrorUrls = articles.map(article => `
  <url>
    <loc>${BASE_URL}/md/${article.slug}.md</loc>
    <lastmod>${formatDate(article.date)}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.3</priority>
  </url>`).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
  xmlns:xhtml="http://www.w3.org/1999/xhtml">
${homepageUrl}
${categoryUrls}
${articleUrls}
${mirrorUrls}
</urlset>`;
}

// ─── Sitemap index (splits into sub-sitemaps by type) ────────────────────────
export function generateSitemapIndex(): string {
  const today = new Date().toISOString().split('T')[0];
  return `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>${BASE_URL}/sitemap.xml</loc>
    <lastmod>${today}</lastmod>
  </sitemap>
</sitemapindex>`;
}

// ─── Download triggers ────────────────────────────────────────────────────────
export function downloadSitemap(articles: Article[]) {
  const xml = generateSitemap(articles);
  downloadFile('sitemap.xml', xml, 'application/xml');
}
