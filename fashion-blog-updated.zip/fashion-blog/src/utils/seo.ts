import { Article } from '../data/articles';

const BASE_URL = 'https://nerien.netlify.app';
const SITE_NAME = 'NE RIEN Magazine';
const DEFAULT_IMAGE = 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200&h=630&fit=crop';
const GOOGLE_VERIFICATION = 'google3b976cd629139867';

/** Set or update a <meta> tag by name or property */
function setMeta(attr: 'name' | 'property', key: string, value: string) {
  let el = document.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement;
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', value);
}

/** Set or update a <link> tag by rel (and optional hreflang) */
function setLink(rel: string, href: string, extra?: Record<string, string>) {
  const selector = extra?.hreflang
    ? `link[rel="${rel}"][hreflang="${extra.hreflang}"]`
    : `link[rel="${rel}"]`;
  let el = document.querySelector(selector) as HTMLLinkElement;
  if (!el) {
    el = document.createElement('link');
    el.setAttribute('rel', rel);
    if (extra) Object.entries(extra).forEach(([k, v]) => el.setAttribute(k, v));
    document.head.appendChild(el);
  }
  el.setAttribute('href', href);
}

/** Inject or replace a JSON-LD <script> block by id */
function setJsonLd(id: string, data: object) {
  let el = document.getElementById(id) as HTMLScriptElement;
  if (!el) {
    el = document.createElement('script');
    el.type = 'application/ld+json';
    el.id = id;
    document.head.appendChild(el);
  }
  el.textContent = JSON.stringify(data, null, 2);
}

/** Remove a JSON-LD block if it exists */
function removeJsonLd(id: string) {
  document.getElementById(id)?.remove();
}

// ─── Homepage SEO ─────────────────────────────────────────────────────────────
export function applyHomeSEO(siteName: string, tagline: string, description: string) {
  const title = `${siteName} | Fashion News, Trends & Culture`;
  const desc = description || `${siteName} — Your premier destination for fashion news, runway coverage, style trends, and exclusive interviews.`;
  const url = BASE_URL;

  document.title = title;

  // Basic
  setMeta('name', 'description', desc);
  setMeta('name', 'robots', 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
  setMeta('name', 'google-site-verification', GOOGLE_VERIFICATION);

  // Canonical & alternates
  setLink('canonical', url);
  setLink('alternate', `${url}/llms.txt`, { type: 'text/plain', title: 'LLMs.txt index' });

  // Open Graph
  setMeta('property', 'og:type', 'website');
  setMeta('property', 'og:url', url);
  setMeta('property', 'og:site_name', SITE_NAME);
  setMeta('property', 'og:title', title);
  setMeta('property', 'og:description', desc);
  setMeta('property', 'og:image', DEFAULT_IMAGE);
  setMeta('property', 'og:image:width', '1200');
  setMeta('property', 'og:image:height', '630');
  setMeta('property', 'og:locale', 'en_US');
  setMeta('property', 'og:locale:alternate', 'es_MX');

  // Twitter / X
  setMeta('name', 'twitter:card', 'summary_large_image');
  setMeta('name', 'twitter:site', '@elanmagazine');
  setMeta('name', 'twitter:title', title);
  setMeta('name', 'twitter:description', desc);
  setMeta('name', 'twitter:image', DEFAULT_IMAGE);

  // hreflang
  setLink('alternate', url, { hreflang: 'en' });
  setLink('alternate', url, { hreflang: 'es' });
  setLink('alternate', url, { hreflang: 'x-default' });

  // JSON-LD: WebSite + Organization + Sitelinks Searchbox
  setJsonLd('schema-website', {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'NewsMediaOrganization',
        '@id': `${BASE_URL}/#organization`,
        name: SITE_NAME,
        url: BASE_URL,
        logo: {
          '@type': 'ImageObject',
          url: `${BASE_URL}/logo.png`,
          width: 200,
          height: 60,
        },
        sameAs: [
          'https://instagram.com/elanmagazine',
          'https://threads.net/@elanmagazine',
          'https://facebook.com/nerien',
          'https://pinterest.com/nerien',
        ],
        foundingDate: '2024',
        knowsAbout: ['Fashion', 'Haute Couture', 'Runway Shows', 'Style Trends', 'Beauty', 'México City Fashion'],
        publishingPrinciples: `${BASE_URL}/about`,
        inLanguage: ['en', 'es'],
      },
      {
        '@type': 'WebSite',
        '@id': `${BASE_URL}/#website`,
        url: BASE_URL,
        name: SITE_NAME,
        description: desc,
        publisher: { '@id': `${BASE_URL}/#organization` },
        inLanguage: ['en', 'es'],
        potentialAction: {
          '@type': 'SearchAction',
          target: { '@type': 'EntryPoint', urlTemplate: `${BASE_URL}/?search={search_term_string}` },
          'query-input': 'required name=search_term_string',
        },
      },
    ],
  });

  // Remove article-specific schemas
  removeJsonLd('schema-article');
  removeJsonLd('schema-breadcrumb');
}

// ─── Article SEO ──────────────────────────────────────────────────────────────
export function applyArticleSEO(article: Article, relatedArticles: Article[] = []) {
  const url = `${BASE_URL}/article/${article.slug}`;
  const mirrorUrl = `${BASE_URL}/md/${article.slug}.md`;
  const categoryLabel = article.category.charAt(0).toUpperCase() + article.category.slice(1);
  const categoryUrl = `${BASE_URL}/category/${article.category}`;

  // Title optimized for CTR: keyword first, pipe brand
  const title = `${article.title} | ${SITE_NAME}`;
  const desc = article.excerpt.length > 155
    ? article.excerpt.slice(0, 152) + '…'
    : article.excerpt;

  document.title = title;

  // Basic
  setMeta('name', 'description', desc);
  setMeta('name', 'author', article.author);
  setMeta('name', 'robots', 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
  setMeta('name', 'google-site-verification', GOOGLE_VERIFICATION);

  // Canonical + Markdown mirror alternate
  setLink('canonical', url);
  setLink('alternate', mirrorUrl, { type: 'text/markdown', title: 'Markdown version' });

  // Open Graph — article type
  setMeta('property', 'og:type', 'article');
  setMeta('property', 'og:url', url);
  setMeta('property', 'og:site_name', SITE_NAME);
  setMeta('property', 'og:title', article.title);
  setMeta('property', 'og:description', desc);
  setMeta('property', 'og:image', article.image);
  setMeta('property', 'og:image:width', '1200');
  setMeta('property', 'og:image:height', '630');
  setMeta('property', 'og:locale', 'en_US');

  // Article-specific OG
  setMeta('property', 'article:published_time', article.date);
  setMeta('property', 'article:modified_time', article.date);
  setMeta('property', 'article:author', article.author);
  setMeta('property', 'article:section', categoryLabel);
  setMeta('property', 'article:tag', article.category);

  // Twitter / X
  setMeta('name', 'twitter:card', 'summary_large_image');
  setMeta('name', 'twitter:site', '@elanmagazine');
  setMeta('name', 'twitter:creator', `@${article.author.replace(/\s+/g, '').toLowerCase()}`);
  setMeta('name', 'twitter:title', article.title);
  setMeta('name', 'twitter:description', desc);
  setMeta('name', 'twitter:image', article.image);
  setMeta('name', 'twitter:label1', 'Written by');
  setMeta('name', 'twitter:data1', article.author);
  setMeta('name', 'twitter:label2', 'Reading time');
  setMeta('name', 'twitter:data2', article.readTime);

  // hreflang
  setLink('alternate', url, { hreflang: 'en' });
  setLink('alternate', url, { hreflang: 'x-default' });
  if (article.titleEs) {
    setLink('alternate', url, { hreflang: 'es' });
  }

  // JSON-LD: NewsArticle
  setJsonLd('schema-article', {
    '@context': 'https://schema.org',
    '@type': 'NewsArticle',
    '@id': url,
    headline: article.title,
    description: desc,
    datePublished: article.date,
    dateModified: article.date,
    url,
    image: {
      '@type': 'ImageObject',
      url: article.image,
      width: 1200,
      height: 630,
    },
    author: {
      '@type': 'Person',
      name: article.author,
      image: article.authorImage,
      worksFor: { '@id': `${BASE_URL}/#organization` },
    },
    publisher: { '@id': `${BASE_URL}/#organization` },
    mainEntityOfPage: { '@type': 'WebPage', '@id': url },
    articleSection: categoryLabel,
    inLanguage: 'en',
    isAccessibleForFree: true,
    ...(relatedArticles.length > 0 && {
      relatedLink: relatedArticles.map(r => `${BASE_URL}/article/${r.slug}`),
    }),
  });

  // JSON-LD: BreadcrumbList
  setJsonLd('schema-breadcrumb', {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: BASE_URL },
      { '@type': 'ListItem', position: 2, name: categoryLabel, item: categoryUrl },
      { '@type': 'ListItem', position: 3, name: article.title, item: url },
    ],
  });
}

// ─── Category SEO ─────────────────────────────────────────────────────────────
export function applyCategorySEO(categoryId: string, categoryName: string, articleCount: number) {
  const url = `${BASE_URL}/category/${categoryId}`;
  const title = `${categoryName} — Fashion ${categoryName} News & Analysis | ${SITE_NAME}`;
  const desc = `Explore the latest ${categoryName.toLowerCase()} coverage on ${SITE_NAME}. ${articleCount} articles on trends, runway looks, and style insights.`;

  document.title = title;
  setMeta('name', 'description', desc);
  setMeta('name', 'robots', 'index, follow, max-snippet:-1, max-image-preview:large');
  setMeta('property', 'og:type', 'website');
  setMeta('property', 'og:url', url);
  setMeta('property', 'og:title', title);
  setMeta('property', 'og:description', desc);
  setMeta('property', 'og:image', DEFAULT_IMAGE);
  setMeta('name', 'twitter:card', 'summary_large_image');
  setMeta('name', 'twitter:title', title);
  setMeta('name', 'twitter:description', desc);
  setLink('canonical', url);

  setJsonLd('schema-article', {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    name: title,
    description: desc,
    url,
    publisher: { '@id': `${BASE_URL}/#organization` },
  });

  setJsonLd('schema-breadcrumb', {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: BASE_URL },
      { '@type': 'ListItem', position: 2, name: categoryName, item: url },
    ],
  });

  removeJsonLd('schema-website');
}
