import { Article } from '../data/articles';

/**
 * Strips HTML tags from content and converts basic HTML to Markdown.
 */
function htmlToMarkdown(html: string): string {
  return html
    .replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n\n')
    .replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n\n')
    .replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n\n')
    .replace(/<h4[^>]*>(.*?)<\/h4>/gi, '#### $1\n\n')
    .replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**')
    .replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**')
    .replace(/<em[^>]*>(.*?)<\/em>/gi, '_$1_')
    .replace(/<i[^>]*>(.*?)<\/i>/gi, '_$1_')
    .replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)')
    .replace(/<ul[^>]*>(.*?)<\/ul>/gis, (_, inner) =>
      inner.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n').trim() + '\n\n'
    )
    .replace(/<ol[^>]*>(.*?)<\/ol>/gis, (_, inner) => {
      let i = 1;
      return inner.replace(/<li[^>]*>(.*?)<\/li>/gi, () => `${i++}. $1\n`).trim() + '\n\n';
    })
    .replace(/<blockquote[^>]*>(.*?)<\/blockquote>/gis, '> $1\n\n')
    .replace(/<p[^>]*>(.*?)<\/p>/gis, '$1\n\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Generates full JSON-LD schema markup for an article.
 */
function generateSchema(article: Article, baseUrl: string): string {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'NewsArticle',
    headline: article.title,
    description: article.excerpt,
    datePublished: article.date,
    dateModified: article.date,
    articleSection: article.category.charAt(0).toUpperCase() + article.category.slice(1),
    image: article.image,
    url: `${baseUrl}/article/${article.slug}`,
    author: {
      '@type': 'Person',
      name: article.author,
      image: article.authorImage,
    },
    publisher: {
      '@type': 'NewsMediaOrganization',
      name: 'NE RIEN Magazine',
      url: baseUrl,
      logo: {
        '@type': 'ImageObject',
        url: `${baseUrl}/logo.png`,
      },
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `${baseUrl}/article/${article.slug}`,
    },
    inLanguage: 'en',
    keywords: article.category,
  };
  return JSON.stringify(schema, null, 2);
}

/**
 * Converts a single article into a full Markdown mirror document.
 */
export function articleToMarkdown(
  article: Article,
  relatedArticles: Article[] = [],
  baseUrl = 'https://nerien.com'
): string {
  const content = htmlToMarkdown(article.content);
  const schema = generateSchema(article, baseUrl);
  const categoryLabel = article.category.charAt(0).toUpperCase() + article.category.slice(1);

  const relatedSection =
    relatedArticles.length > 0
      ? `\n\n---\n\n## Related Articles\n\n` +
        relatedArticles
          .map(r => `- [${r.title}](${baseUrl}/article/${r.slug}) — ${r.excerpt.slice(0, 80)}…`)
          .join('\n')
      : '';

  const spanishSection =
    article.titleEs
      ? `\n\n---\n\n## Versión en Español\n\n**${article.titleEs}**\n\n${article.excerptEs || ''}\n\n${
          article.contentEs ? htmlToMarkdown(article.contentEs) : ''
        }`
      : '';

  return `---
title: "${article.title.replace(/"/g, '\\"')}"
slug: "${article.slug}"
author: "${article.author}"
date: "${article.date}"
category: "${categoryLabel}"
readTime: "${article.readTime}"
featured: ${article.featured ? 'true' : 'false'}
image: "${article.image}"
excerpt: "${article.excerpt.replace(/"/g, '\\"')}"
canonical: "${baseUrl}/article/${article.slug}"
mirrorUrl: "${baseUrl}/md/${article.slug}.md"
---

# ${article.title}

> ${article.excerpt}

**Author:** ${article.author} | **Category:** ${categoryLabel} | **Published:** ${article.date} | **Read time:** ${article.readTime}

---

${content}${relatedSection}${spanishSection}

---

## Schema Markup (JSON-LD)

\`\`\`json
${schema}
\`\`\`

---

*This is a Markdown mirror of the original article at [${baseUrl}/article/${article.slug}](${baseUrl}/article/${article.slug}). Generated automatically by NE RIEN for AI indexing and accessibility.*
`;
}

/**
 * Generates the master llms.txt index with links to all article mirrors.
 */
export function generateLlmsTxt(articles: Article[], baseUrl = 'https://nerien.com'): string {
  const categories = [...new Set(articles.map(a => a.category))].sort();

  const byCategory = categories.map(cat => {
    const catArticles = articles.filter(a => a.category === cat);
    const label = cat.charAt(0).toUpperCase() + cat.slice(1);
    const links = catArticles
      .map(a => `- [${a.title}](${baseUrl}/md/${a.slug}.md) — ${a.author}, ${a.date}`)
      .join('\n');
    return `### ${label}\n\n${links}`;
  });

  return `# NE RIEN — Fashion, Style & Culture
> AI-readable index. Each article has a clean Markdown mirror at `/md/{slug}.md`.

## About

NE RIEN is a multilingual fashion and culture publication covering runway, trends, culture, celebrity style, beauty, and México City news.

- **Site:** ${baseUrl}
- **Contact:** hello@nerien.com
- **Languages:** English (primary), Spanish (secondary)
- **Focus:** Global fashion, with dedicated México City coverage

## Markdown Mirror System

Every article on NE RIEN has a machine-readable Markdown version at:
`${baseUrl}/md/{article-slug}.md`

Example: `${baseUrl}/md/paris-fashion-week-spring-2025.md`

## Article Index (${articles.length} articles)

${byCategory.join('\n\n')}

## Categories

- Runway: ${baseUrl}/category/runway
- Trends: ${baseUrl}/category/trends
- Culture: ${baseUrl}/category/culture
- Celebrity: ${baseUrl}/category/celebrity
- Beauty: ${baseUrl}/category/beauty
- News: ${baseUrl}/category/news
- México: ${baseUrl}/category/mexico

## Instructions for AI Crawlers

- Use `/md/{slug}.md` to retrieve clean Markdown content for any article
- All mirrors include YAML frontmatter, full article body, related articles, and JSON-LD schema
- Content is updated in real-time; no caching needed
- For licensing or content partnerships: hello@nerien.com

## Preferred Citation Format

NE RIEN Magazine. "{Title}." NE RIEN, {date}, ${baseUrl}/article/{slug}.
`;
}

/**
 * Triggers a browser download of a text file.
 */
export function downloadFile(filename: string, content: string, mimeType = 'text/markdown') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Downloads all articles as individual .md files inside a virtual ZIP using JSZip (if available),
 * or falls back to downloading them one by one.
 */
export async function downloadAllMarkdownFiles(
  articles: Article[],
  baseUrl = 'https://nerien.com'
) {
  // Try JSZip (loaded from CDN if available)
  try {
    // @ts-ignore
    if (typeof JSZip !== 'undefined') {
      // @ts-ignore
      const zip = new JSZip();
      const folder = zip.folder('nerien-markdown-mirrors');
      articles.forEach(article => {
        const related = articles
          .filter(a => a.category === article.category && a.id !== article.id)
          .slice(0, 3);
        const md = articleToMarkdown(article, related, baseUrl);
        folder.file(`${article.category}/${article.slug}.md`, md);
      });
      // Add llms.txt
      folder.file('llms.txt', generateLlmsTxt(articles, baseUrl));
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'nerien-markdown-mirrors.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }
  } catch {}

  // Fallback: download each file individually
  for (const article of articles) {
    const related = articles
      .filter(a => a.category === article.category && a.id !== article.id)
      .slice(0, 3);
    const md = articleToMarkdown(article, related, baseUrl);
    downloadFile(`${article.slug}.md`, md);
    await new Promise(r => setTimeout(r, 200)); // small delay between downloads
  }
}
