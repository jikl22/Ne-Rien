import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface SiteSettings {
  // Branding
  siteName: string;
  siteTagline: string;
  siteDescription: string;
  logoText: string;
  logoImage: string; // base64 or URL for logo image
  
  // SEO
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  
  // Hero Section
  heroTitle: string;
  heroSubtitle: string;
  
  // Newsletter
  newsletterTitle: string;
  newsletterSubtitle: string;
  newsletterButtonText: string;
  
  // Footer
  footerAbout: string;
  footerCopyright: string;
  
  // Social Links
  socialInstagram: string;
  instagramHandle: string; // e.g. elanmagazine (without @)
  socialTwitter: string;
  socialFacebook: string;
  socialPinterest: string;
  socialYoutube: string;
  
  // Contact
  contactEmail: string;
  contactAddress: string;
  
  // Categories (customizable names)
  categories: {
    id: string;
    name: string;
    description: string;
  }[];
  
  // Navigation Links
  navLinks: {
    label: string;
    path: string;
    enabled: boolean;
  }[];
}

const defaultSettings: SiteSettings = {
  // Branding
  siteName: 'NE RIEN',
  siteTagline: 'The Art of Fashion',
  siteDescription: 'Your premier destination for fashion news, trends, runway coverage, and style inspiration.',
  logoText: 'NE RIEN',
  logoImage: '',
  
  // SEO
  seoTitle: 'NE RIEN - Fashion, Style & Culture',
  seoDescription: 'Discover the latest fashion trends, runway coverage, celebrity style, and beauty tips at NE RIEN.',
  seoKeywords: 'fashion, style, trends, runway, beauty, celebrity fashion, fashion news',
  
  // Hero Section
  heroTitle: 'Defining Modern Elegance',
  heroSubtitle: 'Explore the intersection of fashion, culture, and the art of self-expression',
  
  // Newsletter
  newsletterTitle: 'Stay in Style',
  newsletterSubtitle: 'Subscribe to our newsletter for exclusive fashion insights and early access to our latest stories.',
  newsletterButtonText: 'Subscribe',
  
  // Footer
  footerAbout: 'NE RIEN is your premier destination for fashion news, trends, runway coverage, and style inspiration. We celebrate the art of fashion and the creative minds shaping the industry.',
  footerCopyright: '© 2024 NE RIEN. All rights reserved.',
  
  // Social Links
  socialInstagram: 'https://instagram.com',
  instagramHandle: 'elanmagazine',
  socialTwitter: 'https://twitter.com',
  socialFacebook: 'https://facebook.com',
  socialPinterest: 'https://pinterest.com',
  socialYoutube: 'https://youtube.com',
  
  // Contact
  contactEmail: 'hello@nerien.com',
  contactAddress: 'New York, NY',
  
  // Categories
  categories: [
    { id: 'runway', name: 'Runway', description: 'Coverage from the world\'s most prestigious fashion weeks' },
    { id: 'trends', name: 'Trends', description: 'The latest styles shaping the fashion landscape' },
    { id: 'culture', name: 'Culture', description: 'Where fashion meets art, music, and society' },
    { id: 'celebrity', name: 'Celebrity', description: 'Iconic looks from the world\'s most stylish stars' },
    { id: 'beauty', name: 'Beauty', description: 'Tips, trends, and transformations in beauty' },
    { id: 'news', name: 'News', description: 'Breaking stories from the fashion industry' },
    { id: 'mexico', name: 'México', description: 'Noticias y tendencias desde la Ciudad de México' },
  ],
  
  // Navigation
  navLinks: [
    { label: 'Home', path: '/', enabled: true },
    { label: 'Runway', path: '/category/runway', enabled: true },
    { label: 'Trends', path: '/category/trends', enabled: true },
    { label: 'Culture', path: '/category/culture', enabled: true },
    { label: 'Celebrity', path: '/category/celebrity', enabled: true },
    { label: 'Beauty', path: '/category/beauty', enabled: true },
    { label: 'News', path: '/category/news', enabled: true },
    { label: 'México', path: '/category/mexico', enabled: true },
  ],
};

interface SiteSettingsContextType {
  settings: SiteSettings;
  updateSettings: (newSettings: Partial<SiteSettings>) => void;
  resetSettings: () => void;
  getCategoryName: (id: string) => string;
  getCategoryDescription: (id: string) => string;
}

const SiteSettingsContext = createContext<SiteSettingsContextType | undefined>(undefined);

const STORAGE_KEY = 'nerien_site_settings';

export const SiteSettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SiteSettings>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        return { ...defaultSettings, ...JSON.parse(stored) };
      } catch {
        return defaultSettings;
      }
    }
    return defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  const updateSettings = (newSettings: Partial<SiteSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
    localStorage.removeItem(STORAGE_KEY);
  };

  const getCategoryName = (id: string): string => {
    const category = settings.categories.find(c => c.id === id);
    return category?.name || id;
  };

  const getCategoryDescription = (id: string): string => {
    const category = settings.categories.find(c => c.id === id);
    return category?.description || '';
  };

  return (
    <SiteSettingsContext.Provider value={{ 
      settings, 
      updateSettings, 
      resetSettings,
      getCategoryName,
      getCategoryDescription
    }}>
      {children}
    </SiteSettingsContext.Provider>
  );
};

export const useSiteSettings = () => {
  const context = useContext(SiteSettingsContext);
  if (!context) {
    throw new Error('useSiteSettings must be used within SiteSettingsProvider');
  }
  return context;
};
