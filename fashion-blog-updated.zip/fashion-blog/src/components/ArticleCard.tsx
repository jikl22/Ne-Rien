import { Article } from '../data/articles';
import { useTranslation } from '../context/TranslationContext';
import { cn } from '../utils/cn';

interface ArticleCardProps {
  article: Article;
  variant?: 'default' | 'featured' | 'horizontal' | 'minimal';
  onClick: () => void;
}

export function ArticleCard({ article, variant = 'default', onClick }: ArticleCardProps) {
  const { language, t } = useTranslation();
  const title = language === 'es' && article.titleEs ? article.titleEs : article.title;
  const excerpt = language === 'es' && article.excerptEs ? article.excerptEs : article.excerpt;
  const categoryName = t[article.category as keyof typeof t] || article.category;

  const categoryColors: Record<string, string> = {
    runway: 'bg-purple-100 text-purple-800',
    trends: 'bg-rose-100 text-rose-800',
    culture: 'bg-amber-100 text-amber-800',
    celebrity: 'bg-pink-100 text-pink-800',
    beauty: 'bg-emerald-100 text-emerald-800',
    news: 'bg-blue-100 text-blue-800',
    mexico: 'bg-orange-100 text-orange-800',
  };

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  /* ── Featured hero ── */
  if (variant === 'featured') {
    return (
      <article onClick={onClick} className="group cursor-pointer relative overflow-hidden bg-black">
        {/* Mobile: 3:2 | Tablet: 16:9 | Desktop: 21:9 */}
        <div className="aspect-[3/2] sm:aspect-[16/9] lg:aspect-[21/9]">
          <img src={article.image} alt={title}
            className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:opacity-50 group-hover:scale-105 transition-all duration-700" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-8 lg:p-12 text-white">
          <span className={cn('inline-block px-3 py-1 text-xs uppercase tracking-wider font-medium mb-3', categoryColors[article.category])}>
            {categoryName}
          </span>
          <h2 className="text-xl sm:text-3xl lg:text-5xl font-serif font-bold leading-tight mb-3 group-hover:underline decoration-2 underline-offset-4"
            style={{ fontFamily: "'Playfair Display', serif" }}>
            {title}
          </h2>
          <p className="text-gray-200 text-sm sm:text-base max-w-2xl mb-3 line-clamp-2 hidden sm:block">{excerpt}</p>
          <div className="flex items-center gap-3 text-xs sm:text-sm text-gray-300 flex-wrap">
            <span>{t.by} {article.author}</span>
            <span>•</span>
            <span>{formatDate(article.date)}</span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline">{article.readTime} {t.minRead}</span>
          </div>
        </div>
      </article>
    );
  }

  /* ── Horizontal list item ── */
  if (variant === 'horizontal') {
    return (
      <article onClick={onClick}
        className="group cursor-pointer flex gap-4 sm:gap-6 py-5 border-b border-gray-100 last:border-0">
        {/* Fixed square thumb — bigger on tablet+ */}
        <div className="flex-shrink-0 w-24 h-24 sm:w-36 sm:h-28 lg:w-44 lg:h-32 overflow-hidden rounded-sm">
          <img src={article.image} alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        </div>
        <div className="flex-1 min-w-0">
          <span className={cn('inline-block px-2 py-0.5 text-xs uppercase tracking-wider font-medium mb-1.5', categoryColors[article.category])}>
            {categoryName}
          </span>
          <h3 className="text-base sm:text-lg font-serif font-semibold leading-snug mb-2 group-hover:underline decoration-1 underline-offset-2 line-clamp-2 sm:line-clamp-3"
            style={{ fontFamily: "'Playfair Display', serif" }}>
            {title}
          </h3>
          <p className="text-gray-500 text-sm line-clamp-2 mb-2 hidden md:block">{excerpt}</p>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <span>{formatDate(article.date)}</span>
            <span>•</span>
            <span>{article.readTime}</span>
          </div>
        </div>
      </article>
    );
  }

  /* ── Minimal ── */
  if (variant === 'minimal') {
    return (
      <article onClick={onClick} className="group cursor-pointer py-3 border-b border-gray-100 last:border-0">
        <span className="text-xs uppercase tracking-wider text-gray-500 mb-1 block">{categoryName}</span>
        <h3 className="font-serif font-semibold leading-snug group-hover:underline decoration-1 underline-offset-2 text-sm sm:text-base"
          style={{ fontFamily: "'Playfair Display', serif" }}>
          {title}
        </h3>
      </article>
    );
  }

  /* ── Default card ── */
  return (
    <article onClick={onClick} className="group cursor-pointer">
      {/* Portrait on mobile → landscape on desktop */}
      <div className="aspect-[4/3] sm:aspect-[3/2] lg:aspect-[4/5] overflow-hidden mb-4">
        <img src={article.image} alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
      </div>
      <span className={cn('inline-block px-2 py-0.5 text-xs uppercase tracking-wider font-medium mb-2', categoryColors[article.category])}>
        {categoryName}
      </span>
      <h3 className="text-lg sm:text-xl font-serif font-semibold leading-snug mb-2 group-hover:underline decoration-1 underline-offset-2"
        style={{ fontFamily: "'Playfair Display', serif" }}>
        {title}
      </h3>
      <p className="text-gray-600 text-sm line-clamp-2 mb-3">{excerpt}</p>
      <div className="flex items-center gap-3">
        <img src={article.authorImage} alt={article.author} className="w-8 h-8 rounded-full object-cover" />
        <div className="text-xs text-gray-500">
          <span className="font-medium text-gray-900">{article.author}</span>
          <span className="mx-1.5">•</span>
          <span>{formatDate(article.date)}</span>
        </div>
      </div>
    </article>
  );
}
