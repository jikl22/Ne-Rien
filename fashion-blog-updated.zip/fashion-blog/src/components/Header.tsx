import { useState } from 'react';
import { useSiteSettings } from '../context/SiteSettingsContext';
import { useTranslation } from '../context/TranslationContext';
import { cn } from '../utils/cn';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string, data?: string) => void;
}

export function Header({ currentView, onNavigate }: HeaderProps) {
  const { settings } = useSiteSettings();
  const { language, setLanguage, t } = useTranslation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('search', searchQuery);
      setSearchOpen(false);
      setMobileMenuOpen(false);
      setSearchQuery('');
    }
  };

  const navLinks = settings.navLinks.filter(l => l.enabled);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">

      {/* Top bar — desktop only */}
      <div className="hidden lg:block bg-black text-white text-xs py-2">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <span className="tracking-wide">The destination for fashion-forward individuals</span>
          <div className="flex gap-6">
            <a href="#newsletter" className="hover:underline">Newsletter</a>
            <a href="#subscribe" className="hover:underline">Subscribe</a>
          </div>
        </div>
      </div>

      {/* Main header row */}
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="relative flex items-center justify-between h-14 sm:h-16 lg:h-20">

          {/* Hamburger — mobile/tablet */}
          <button
            onClick={() => { setMobileMenuOpen(!mobileMenuOpen); setSearchOpen(false); }}
            className="lg:hidden p-2 -ml-1 rounded hover:bg-gray-100 transition-colors"
            aria-label="Toggle menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen
                ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
                : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>

          {/* Logo — centered on mobile, natural flow on desktop */}
          <button
            onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }}
            className="absolute left-1/2 -translate-x-1/2 lg:static lg:left-auto lg:translate-x-0 font-serif font-bold tracking-wider hover:opacity-70 transition-opacity text-xl sm:text-2xl lg:text-4xl whitespace-nowrap"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {settings.logoImage
              ? <img src={settings.logoImage} alt={settings.logoText} className="h-8 sm:h-9 lg:h-11 max-w-[150px] sm:max-w-[180px] lg:max-w-[240px] object-contain" />
              : settings.logoText}
          </button>

          {/* Right actions */}
          <div className="flex items-center gap-1">
            <div className="hidden sm:flex items-center border border-gray-200 rounded overflow-hidden mr-1">
              {(['en', 'es'] as const).map(lang => (
                <button key={lang} onClick={() => setLanguage(lang)}
                  className={cn('px-2 py-1 text-xs font-medium transition-colors',
                    language === lang ? 'bg-black text-white' : 'bg-white text-gray-600 hover:bg-gray-100')}>
                  {lang.toUpperCase()}
                </button>
              ))}
            </div>
            <button onClick={() => { setSearchOpen(!searchOpen); setMobileMenuOpen(false); }}
              className="p-2 rounded hover:bg-gray-100 transition-colors" aria-label={t.search}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
            <button onClick={() => onNavigate('admin')}
              className="p-2 text-gray-400 hover:text-black rounded hover:bg-gray-100 transition-colors" title={t.adminPanel}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
        </div>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center justify-center gap-6 xl:gap-8 py-3 border-t border-gray-100">
          {navLinks.map(link => {
            const cat = link.path.startsWith('/category/') ? link.path.replace('/category/', '') : null;
            const isActive = link.path === '/' ? currentView === 'home' : cat ? currentView === `category-${cat}` : false;
            return (
              <button key={link.path}
                onClick={() => { if (link.path === '/') onNavigate('home'); else if (cat) onNavigate('category', cat); }}
                className={cn('text-xs tracking-widest uppercase font-medium transition-colors whitespace-nowrap',
                  isActive ? 'text-black border-b-2 border-black pb-0.5' : 'text-gray-700 hover:text-gray-400')}>
                {link.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Search dropdown */}
      {searchOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-lg z-50">
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto px-4 py-4 sm:py-5">
            <div className="relative">
              <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder} autoFocus
                className="w-full px-4 py-3 pr-12 border border-gray-300 focus:outline-none focus:border-black text-base sm:text-lg" />
              <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2">
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-xl z-50">
          <div className="sm:hidden flex gap-2 px-4 pt-3 pb-2 border-b border-gray-100">
            {(['en', 'es'] as const).map(lang => (
              <button key={lang} onClick={() => setLanguage(lang)}
                className={cn('flex-1 py-2 text-sm font-medium rounded transition-colors',
                  language === lang ? 'bg-black text-white' : 'bg-gray-100 text-gray-700')}>
                {lang === 'en' ? '🇬🇧 English' : '🇲🇽 Español'}
              </button>
            ))}
          </div>
          <nav className="py-1">
            {navLinks.map(link => {
              const cat = link.path.startsWith('/category/') ? link.path.replace('/category/', '') : null;
              const isActive = link.path === '/' ? currentView === 'home' : cat ? currentView === `category-${cat}` : false;
              return (
                <button key={link.path}
                  onClick={() => { if (link.path === '/') onNavigate('home'); else if (cat) onNavigate('category', cat); setMobileMenuOpen(false); }}
                  className={cn('w-full px-6 py-4 text-left text-sm tracking-widest uppercase font-medium transition-colors border-b border-gray-50 last:border-0',
                    isActive ? 'bg-black text-white' : 'text-gray-800 hover:bg-gray-50')}>
                  {link.label}
                </button>
              );
            })}
          </nav>
        </div>
      )}
    </header>
  );
}
