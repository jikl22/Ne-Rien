import { Article } from '../data/articles';
import { ArticleCard } from '../components/ArticleCard';
import { useArticles } from '../context/ArticleContext';
import { useTranslation } from '../context/TranslationContext';
import { useAuthors } from '../context/AuthorsContext';

interface ArticlePageProps {
  article: Article;
  onArticleClick: (slug: string) => void;
  onCategoryClick: (category: string) => void;
}

export function ArticlePage({ article, onArticleClick, onCategoryClick }: ArticlePageProps) {
  const { getArticlesByCategory } = useArticles();
  const { language, t } = useTranslation();
  const { getAuthorByName } = useAuthors();
  
  // Get author info from Authors context
  const authorInfo = getAuthorByName(article.author);
  
  // Get translated content if available
  const title = language === 'es' && article.titleEs ? article.titleEs : article.title;
  const excerpt = language === 'es' && article.excerptEs ? article.excerptEs : article.excerpt;
  const content = language === 'es' && article.contentEs ? article.contentEs : article.content;
  
  const relatedArticles = getArticlesByCategory(article.category)
    .filter(a => a.id !== article.id)
    .slice(0, 3);

  const categoryColors: Record<string, string> = {
    runway: 'bg-purple-100 text-purple-800',
    trends: 'bg-rose-100 text-rose-800',
    culture: 'bg-amber-100 text-amber-800',
    celebrity: 'bg-pink-100 text-pink-800',
    beauty: 'bg-emerald-100 text-emerald-800',
    news: 'bg-blue-100 text-blue-800',
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <article className="pb-20">
      {/* Hero */}
      <header className="relative">
        <div className="aspect-[3/2] sm:aspect-[16/9] lg:aspect-[21/9] overflow-hidden">
          <img
            src={article.image}
            alt={article.title}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      </header>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 -mt-12 sm:-mt-24 lg:-mt-32 relative z-10">
        <div className="bg-white p-5 sm:p-8 lg:p-12 shadow-lg">
          {/* Meta */}
          <div className="mb-6">
            <button
              onClick={() => onCategoryClick(article.category)}
              className={`inline-block px-3 py-1 text-xs uppercase tracking-wider font-medium ${categoryColors[article.category]} hover:opacity-80 transition-opacity`}
            >
              {article.category}
            </button>
          </div>

          {/* Title */}
          <h1 
            className="text-2xl sm:text-3xl lg:text-5xl font-serif font-bold leading-tight mb-5 sm:mb-6"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {title}
          </h1>

          {/* Excerpt */}
          <p className="text-xl text-gray-600 leading-relaxed mb-8 font-serif italic">
            {excerpt}
          </p>

          {/* Author info */}
          <div className="flex items-center gap-4 pb-8 border-b border-gray-200">
            <img
              src={article.authorImage}
              alt={article.author}
              className="w-14 h-14 rounded-full object-cover"
            />
            <div>
              <p className="font-semibold text-lg">{article.author}</p>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <time dateTime={article.date}>{formatDate(article.date)}</time>
                <span>•</span>
                <span>{article.readTime} {t.minRead}</span>
              </div>
            </div>
          </div>

          {/* Share buttons */}
          <div className="flex items-center gap-4 py-6 border-b border-gray-200 mb-10">
            <span className="text-sm text-gray-500 uppercase tracking-wider">{t.share}</span>
            <div className="flex gap-3">
              <button 
                className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                aria-label="Share on Twitter"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </button>
              <button 
                className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                aria-label="Share on Facebook"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </button>
              <button 
                className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                aria-label="Share on Pinterest"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.373 0 0 5.372 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/>
                </svg>
              </button>
              <button 
                className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                aria-label="Copy link"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                </svg>
              </button>
            </div>
          </div>

          {/* Article content */}
          <div 
            className="prose prose-lg max-w-none prose-headings:font-serif prose-headings:font-bold prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4 prose-p:text-gray-700 prose-p:leading-relaxed prose-a:text-black prose-a:underline"
            dangerouslySetInnerHTML={{ __html: content }}
            style={{ fontFamily: "'Inter', sans-serif" }}
          />

          {/* Tags */}
          <div className="mt-12 pt-8 border-t border-gray-200">
            <div className="flex flex-wrap gap-2">
              <span className="text-sm text-gray-500 mr-2">{t.tags}:</span>
              {['Fashion', 'Style', article.category, '2024'].map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 bg-gray-100 text-sm text-gray-600 hover:bg-gray-200 cursor-pointer transition-colors"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Author bio */}
        <div className="bg-gray-50 p-8 mt-8">
          <div className="flex flex-col sm:flex-row gap-6 items-center sm:items-start">
            <img
              src={authorInfo?.photo || article.authorImage}
              alt={article.author}
              className="w-24 h-24 rounded-full object-cover"
            />
            <div className="text-center sm:text-left">
              <h3 className="font-semibold text-lg mb-2">{t.about} {article.author}</h3>
              {authorInfo?.role && (
                <p className="text-gray-500 text-sm mb-2 italic">{authorInfo.role}</p>
              )}
              <p className="text-gray-600 text-sm leading-relaxed mb-4">
                {authorInfo?.bio || `${article.author} is a fashion journalist and editor at NE RIEN Magazine, covering runway shows, industry news, and emerging trends.`}
              </p>
              {/* Social links */}
              {authorInfo && (authorInfo.instagram || authorInfo.threads || authorInfo.twitter || authorInfo.website) && (
                <div className="flex gap-3 mb-4 justify-center sm:justify-start">
                  {authorInfo.instagram && (
                    <a 
                      href={authorInfo.instagram} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                      aria-label="Instagram"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                      </svg>
                    </a>
                  )}
                  {(authorInfo.threads || authorInfo.twitter) && (
                    <a 
                      href={authorInfo.threads || authorInfo.twitter} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                      aria-label="Threads"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 192 192">
                        <path d="M141.537 88.988a66.667 66.667 0 0 0-2.518-1.143c-1.482-27.307-16.403-42.94-41.457-43.1h-.34c-14.986 0-27.449 6.396-35.12 18.036l13.779 9.452c5.73-8.695 14.724-10.548 21.348-10.548h.23c8.249.053 14.474 2.452 18.502 7.13 2.932 3.405 4.893 8.11 5.864 14.05-7.314-1.243-15.224-1.626-23.68-1.14-23.82 1.371-39.134 15.264-38.105 34.568.522 9.792 5.4 18.216 13.735 23.719 7.047 4.652 16.124 6.927 25.557 6.412 12.458-.683 22.231-5.436 29.049-14.127 5.178-6.6 8.453-15.153 9.899-25.93 5.937 3.583 10.337 8.298 12.767 13.966 4.132 9.635 4.373 25.468-8.546 38.376-11.319 11.308-24.925 16.2-45.488 16.351-22.809-.169-40.06-7.484-51.275-21.742C35.236 139.966 29.808 120.682 29.605 96c.203-24.682 5.63-43.966 16.133-57.317C56.954 24.425 74.204 17.11 97.013 16.94c22.975.17 40.526 7.52 52.171 21.847 5.71 7.026 10.015 15.86 12.853 26.162l16.147-4.308c-3.44-12.68-8.853-23.606-16.219-32.668C147.036 9.607 125.202.195 97.07 0h-.113C68.882.195 47.292 9.642 32.788 28.08 19.882 44.485 13.224 67.315 13.001 96v.027c.223 28.685 6.88 51.515 19.787 67.92 14.504 18.438 36.094 27.885 64.172 28.08h.114c25.016-.173 42.64-6.727 57.1-21.18 19.022-19.01 18.406-42.717 12.158-57.333-4.557-10.623-13.222-19.289-24.795-24.526ZM98.44 129.507c-10.44.588-21.286-4.098-21.82-14.135-.397-7.442 5.296-15.746 22.461-16.735 1.966-.113 3.895-.169 5.79-.169 6.235 0 12.068.606 17.371 1.765-1.978 24.702-13.58 28.713-23.802 29.274Z"/>
                      </svg>
                    </a>
                  )}
                  {authorInfo.website && (
                    <a 
                      href={authorInfo.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
                      aria-label="Website"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/>
                      </svg>
                    </a>
                  )}
                </div>
              )}
              <button className="text-sm font-medium underline underline-offset-2 hover:no-underline">
                {t.viewAllBy} {article.author}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 mt-16 sm:mt-20">
          <div className="flex items-center justify-between mb-10">
            <h2 
              className="text-2xl lg:text-3xl font-serif font-bold"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              {t.moreIn} {t[article.category as keyof typeof t] || article.category}
            </h2>
            <div className="h-px flex-1 bg-gray-200 ml-8 hidden md:block" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {relatedArticles.map((relatedArticle) => (
              <ArticleCard
                key={relatedArticle.id}
                article={relatedArticle}
                onClick={() => onArticleClick(relatedArticle.slug)}
              />
            ))}
          </div>
        </section>
      )}
    </article>
  );
}
