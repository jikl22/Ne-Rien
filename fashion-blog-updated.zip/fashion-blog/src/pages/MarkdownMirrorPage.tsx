import { useEffect } from 'react';
import { useArticles } from '../context/ArticleContext';
import { articleToMarkdown } from '../utils/markdownMirror';

interface MarkdownMirrorPageProps {
  slug: string;
}

/**
 * Renders a plain-text Markdown response for a given article slug.
 * Triggered when the URL contains ?md=slug.
 * Replaces the entire page content with raw Markdown — ideal for AI crawlers.
 */
export function MarkdownMirrorPage({ slug }: MarkdownMirrorPageProps) {
  const { articles, getArticleBySlug } = useArticles();

  useEffect(() => {
    const article = getArticleBySlug(slug);

    if (!article) {
      document.title = 'Not Found — NE RIEN';
      document.body.innerHTML = `# 404 — Article Not Found\n\nNo article with slug \`${slug}\` exists on NE RIEN.\n\nReturn to: https://nerien.com`;
      document.body.style.cssText =
        'font-family: monospace; white-space: pre-wrap; padding: 2rem; background: #fff; color: #111;';
      return;
    }

    const related = articles
      .filter(a => a.category === article.category && a.id !== article.id)
      .slice(0, 3);

    const baseUrl = window.location.origin;
    const markdown = articleToMarkdown(article, related, baseUrl);

    // Replace page with raw markdown
    document.title = `[MD] ${article.title} — NE RIEN`;

    // Set content-type hint via meta
    const meta = document.createElement('meta');
    meta.httpEquiv = 'Content-Type';
    meta.content = 'text/markdown; charset=utf-8';
    document.head.appendChild(meta);

    // Replace body with raw pre-formatted markdown
    document.body.innerHTML = '';
    document.body.style.cssText =
      'font-family: monospace; white-space: pre-wrap; word-break: break-word; ' +
      'padding: 2rem; background: #fafafa; color: #111; font-size: 14px; line-height: 1.7; margin: 0;';

    const pre = document.createElement('pre');
    pre.textContent = markdown;
    document.body.appendChild(pre);
  }, [slug, articles, getArticleBySlug]);

  return null;
}
