import { ArticleCard } from '../components/ArticleCard';
import { useArticles } from '../context/ArticleContext';
import { useSiteSettings } from '../context/SiteSettingsContext';
import { useTranslation } from '../context/TranslationContext';

interface HomePageProps {
  onArticleClick: (slug: string) => void;
  onCategoryClick: (category: string) => void;
}

export function HomePage({ onArticleClick, onCategoryClick }: HomePageProps) {
  const { articles, getFeaturedArticles, getLatestArticles } = useArticles();
  const { settings } = useSiteSettings();
  const { t } = useTranslation();
  const featuredArticles = getFeaturedArticles();
  const latestArticles = getLatestArticles(6);
  const mainFeatured = featuredArticles[0];
  const secondaryFeatured = featuredArticles[1];

  const getCategoryName = (categoryId: string) => {
    const key = categoryId.toLowerCase() as keyof typeof t;
    return t[key] || categoryId;
  };

  return (
    <main>

      {/* ── Hero featured ── */}
      {mainFeatured && (
        <section className="mb-8 sm:mb-12">
          <ArticleCard article={mainFeatured} variant="featured" onClick={() => onArticleClick(mainFeatured.slug)} />
        </section>
      )}

      {/* ── Category quick links ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-10 sm:mb-16">
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
          {settings.categories.map(cat => (
            <button key={cat.id} onClick={() => onCategoryClick(cat.id)}
              className="px-4 sm:px-6 py-2 border border-gray-200 text-xs sm:text-sm uppercase tracking-wider hover:bg-black hover:text-white hover:border-black transition-all duration-300">
              {getCategoryName(cat.id)}
            </button>
          ))}
        </div>
      </section>

      {/* ── Latest stories grid ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-16 sm:mb-20">
        <div className="flex items-center justify-between mb-7 sm:mb-10">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-serif font-bold"
            style={{ fontFamily: "'Playfair Display', serif" }}>
            {t.latestStories}
          </h2>
          <div className="h-px flex-1 bg-gray-200 ml-6 hidden sm:block" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 lg:gap-x-8 gap-y-10 sm:gap-y-12">
          {latestArticles.slice(0, 3).map(article => (
            <ArticleCard key={article.id} article={article} onClick={() => onArticleClick(article.slug)} />
          ))}
        </div>
      </section>

      {/* ── Secondary featured ── */}
      {secondaryFeatured && (
        <section className="bg-gray-50 py-12 sm:py-16 mb-16 sm:mb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              <div className="aspect-[4/3] sm:aspect-[16/9] lg:aspect-[4/3] overflow-hidden">
                <img src={secondaryFeatured.image} alt={secondaryFeatured.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 cursor-pointer"
                  onClick={() => onArticleClick(secondaryFeatured.slug)} />
              </div>
              <div className="py-2">
                <span className="inline-block px-3 py-1 bg-rose-100 text-rose-800 text-xs uppercase tracking-wider font-medium mb-4">
                  {secondaryFeatured.category}
                </span>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold leading-tight mb-4 cursor-pointer hover:underline decoration-2 underline-offset-4"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                  onClick={() => onArticleClick(secondaryFeatured.slug)}>
                  {secondaryFeatured.title}
                </h2>
                <p className="text-gray-600 text-base sm:text-lg mb-6 leading-relaxed">{secondaryFeatured.excerpt}</p>
                <div className="flex items-center gap-4 mb-6">
                  <img src={secondaryFeatured.authorImage} alt={secondaryFeatured.author}
                    className="w-10 h-10 sm:w-12 sm:h-12 rounded-full object-cover" />
                  <div>
                    <p className="font-medium text-sm sm:text-base">{secondaryFeatured.author}</p>
                    <p className="text-xs sm:text-sm text-gray-500">
                      {new Date(secondaryFeatured.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                      <span className="mx-2">•</span>
                      {secondaryFeatured.readTime} {t.minRead}
                    </p>
                  </div>
                </div>
                <button onClick={() => onArticleClick(secondaryFeatured.slug)}
                  className="px-7 sm:px-8 py-3 bg-black text-white uppercase tracking-wider text-xs sm:text-sm font-medium hover:bg-gray-800 transition-colors">
                  {t.readMore}
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ── More stories + sidebar ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-16 sm:mb-20">
        <div className="grid lg:grid-cols-3 gap-10 lg:gap-12">

          {/* Main column */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-7">
              <h2 className="text-xl sm:text-2xl font-serif font-bold"
                style={{ fontFamily: "'Playfair Display', serif" }}>
                {t.moreStories}
              </h2>
              <div className="h-px flex-1 bg-gray-200 ml-6" />
            </div>
            <div>
              {articles.slice(3, 7).map(article => (
                <ArticleCard key={article.id} article={article} variant="horizontal"
                  onClick={() => onArticleClick(article.slug)} />
              ))}
            </div>
          </div>

          {/* Sidebar — collapses to horizontal stack on mobile */}
          <aside className="lg:block">
            <div className="lg:sticky lg:top-32 space-y-8">

              {/* Newsletter widget */}
              <div className="bg-black text-white p-6 sm:p-8">
                <h3 className="text-lg sm:text-xl font-serif font-bold mb-3"
                  style={{ fontFamily: "'Playfair Display', serif" }}>
                  {t.subscribe} — {settings.siteName}
                </h3>
                <p className="text-gray-400 text-sm mb-5">{settings.newsletterSubtitle}</p>
                <input type="email" placeholder={t.emailPlaceholder}
                  className="w-full px-4 py-2.5 bg-white/10 border border-gray-600 focus:border-white focus:outline-none text-white placeholder-gray-500 mb-3 text-sm" />
                <button className="w-full py-2.5 bg-white text-black font-medium uppercase tracking-wider text-sm hover:bg-gray-200 transition-colors">
                  {t.subscribe}
                </button>
              </div>

              {/* Trending */}
              <div>
                <h3 className="text-base sm:text-lg font-serif font-bold mb-4 pb-2 border-b border-gray-200"
                  style={{ fontFamily: "'Playfair Display', serif" }}>
                  {t.trendingNow}
                </h3>
                {/* On mobile: 2-col grid. On desktop: single column list */}
                <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-1 gap-2 lg:gap-0">
                  {articles.slice(0, 4).map((article, i) => (
                    <div key={article.id} onClick={() => onArticleClick(article.slug)}
                      className="flex gap-3 py-3 lg:border-b lg:border-gray-100 lg:last:border-0 cursor-pointer group">
                      <span className="text-2xl sm:text-3xl font-serif text-gray-200 font-bold leading-none flex-shrink-0">
                        {String(i + 1).padStart(2, '0')}
                      </span>
                      <div className="min-w-0">
                        <span className="text-xs uppercase tracking-wider text-gray-500 block mb-0.5">{article.category}</span>
                        <h4 className="font-medium text-xs sm:text-sm leading-snug group-hover:underline line-clamp-3"
                          style={{ fontFamily: "'Playfair Display', serif" }}>
                          {article.title}
                        </h4>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* ── Instagram panel ── */}
      <section className="bg-black py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-xs uppercase tracking-widest text-gray-400 mb-5 sm:mb-6">Follow us on Instagram</p>
          {/* Mobile: 3 cols | tablet: 4 | desktop: 6 */}
          <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-0.5 sm:gap-1 mb-7 sm:mb-8">
            {[
              'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=400&h=400&fit=crop',
              'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=400&h=400&fit=crop&q=80',
              'https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?w=400&h=400&fit=crop',
              'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=400&h=400&fit=crop',
              'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=400&h=400&fit=crop',
              'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400&h=400&fit=crop',
            ].map((src, i) => (
              <a key={i} href={settings.socialInstagram || 'https://instagram.com'} target="_blank" rel="noopener noreferrer"
                className="aspect-square overflow-hidden group block">
                <img src={src} alt={`Instagram post ${i + 1}`}
                  className="w-full h-full object-cover group-hover:scale-110 group-hover:opacity-70 transition-all duration-500" />
              </a>
            ))}
          </div>
          <a href={settings.socialInstagram || 'https://instagram.com'} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 sm:px-8 py-3 border border-white text-white text-xs sm:text-sm uppercase tracking-widest hover:bg-white hover:text-black transition-colors duration-300">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            Follow on Instagram
          </a>
        </div>
      </section>
    </main>
  );
}
