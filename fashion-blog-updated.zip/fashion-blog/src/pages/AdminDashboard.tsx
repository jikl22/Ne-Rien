import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useArticles } from '../context/ArticleContext';
import { useSiteSettings } from '../context/SiteSettingsContext';
import { Article, categories } from '../data/articles';
import { ArticleEditor } from '../components/ArticleEditor';
import { SiteSettingsEditor } from '../components/admin/SiteSettingsEditor';
import { AuthorsEditor } from '../components/admin/AuthorsEditor';
import { downloadAllMarkdownFiles, generateLlmsTxt, downloadFile } from '../utils/markdownMirror';
import { downloadSitemap } from '../utils/sitemap';

interface AdminDashboardProps {
  onBackToSite: () => void;
}

type AdminView = 'list' | 'create' | 'edit' | 'settings' | 'site-settings' | 'authors';

export function AdminDashboard({ onBackToSite }: AdminDashboardProps) {
  const { logout, changePassword } = useAuth();
  const { articles, deleteArticle } = useArticles();
  const { settings } = useSiteSettings();
  const [view, setView] = useState<AdminView>('list');
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  
  // Settings state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMessage, setPasswordMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [exportingMd, setExportingMd] = useState(false);

  const handleExportMarkdown = async () => {
    setExportingMd(true);
    try {
      const baseUrl = window.location.origin;
      await downloadAllMarkdownFiles(articles, baseUrl);
    } finally {
      setExportingMd(false);
    }
  };

  const handleExportLlmsTxt = () => {
    const baseUrl = window.location.origin;
    const content = generateLlmsTxt(articles, baseUrl);
    downloadFile('llms.txt', content, 'text/plain');
  };

  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || article.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleEdit = (article: Article) => {
    setEditingArticle(article);
    setView('edit');
  };

  const handleDelete = (id: string) => {
    if (deleteConfirm === id) {
      deleteArticle(id);
      setDeleteConfirm(null);
    } else {
      setDeleteConfirm(id);
      setTimeout(() => setDeleteConfirm(null), 3000);
    }
  };

  const handleSaveComplete = () => {
    setView('list');
    setEditingArticle(null);
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMessage(null);

    if (newPassword !== confirmPassword) {
      setPasswordMessage({ type: 'error', text: 'New passwords do not match.' });
      return;
    }

    if (newPassword.length < 4) {
      setPasswordMessage({ type: 'error', text: 'Password must be at least 4 characters.' });
      return;
    }

    if (changePassword(currentPassword, newPassword)) {
      setPasswordMessage({ type: 'success', text: 'Password changed successfully!' });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } else {
      setPasswordMessage({ type: 'error', text: 'Current password is incorrect.' });
    }
  };

  const handleLogout = () => {
    logout();
    onBackToSite();
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-black text-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-6">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-6">
              <h1 
                className="text-xl font-bold tracking-wider"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                {settings.logoText}
              </h1>
              <span className="text-xs uppercase tracking-widest text-gray-400">Admin</span>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={onBackToSite}
                className="text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-1"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
                View Site
              </button>
              <button
                onClick={handleLogout}
                className="text-sm bg-white/10 hover:bg-white/20 px-4 py-2 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
        {/* Navigation Tabs */}
        <div className="flex gap-2 mb-8">
          <button
            onClick={() => { setView('list'); setEditingArticle(null); }}
            className={`px-6 py-2 text-sm font-medium transition-colors ${
              view === 'list' 
                ? 'bg-black text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            All Articles
          </button>
          <button
            onClick={() => { setView('create'); setEditingArticle(null); }}
            className={`px-6 py-2 text-sm font-medium transition-colors ${
              view === 'create' 
                ? 'bg-black text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            + New Article
          </button>
          <button
            onClick={() => setView('authors')}
            className={`px-6 py-2 text-sm font-medium transition-colors ${
              view === 'authors' 
                ? 'bg-black text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            👤 Authors
          </button>
          <button
            onClick={() => setView('site-settings')}
            className={`px-6 py-2 text-sm font-medium transition-colors ${
              view === 'site-settings' 
                ? 'bg-black text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            🎨 Site Settings
          </button>
          <button
            onClick={() => setView('settings')}
            className={`px-6 py-2 text-sm font-medium transition-colors ${
              view === 'settings' 
                ? 'bg-black text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            ⚙️ Account
          </button>
        </div>

        {/* Article List View */}
        {view === 'list' && (
          <div className="bg-white shadow-sm">
            {/* Filters */}
            <div className="p-6 border-b border-gray-100">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <input
                    type="text"
                    placeholder="Search articles..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black"
                  />
                </div>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="px-4 py-2 border border-gray-200 focus:outline-none focus:border-black bg-white"
                >
                  <option value="all">All Categories</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Stats */}
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-100">
              <p className="text-sm text-gray-600">
                Showing <strong>{filteredArticles.length}</strong> of <strong>{articles.length}</strong> articles
              </p>
            </div>

            {/* Article Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left px-6 py-4 text-xs uppercase tracking-wider text-gray-500 font-medium">Article</th>
                    <th className="text-left px-6 py-4 text-xs uppercase tracking-wider text-gray-500 font-medium hidden md:table-cell">Category</th>
                    <th className="text-left px-6 py-4 text-xs uppercase tracking-wider text-gray-500 font-medium hidden lg:table-cell">Author</th>
                    <th className="text-left px-6 py-4 text-xs uppercase tracking-wider text-gray-500 font-medium hidden sm:table-cell">Date</th>
                    <th className="text-left px-6 py-4 text-xs uppercase tracking-wider text-gray-500 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredArticles.map((article) => (
                    <tr key={article.id} className="border-b border-gray-50 hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                          <img
                            src={article.image}
                            alt=""
                            className="w-16 h-12 object-cover hidden sm:block"
                          />
                          <div>
                            <h3 className="font-medium text-sm line-clamp-1">{article.title}</h3>
                            {article.featured && (
                              <span className="text-xs text-amber-600 font-medium">★ Featured</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 hidden md:table-cell">
                        <span className="text-xs uppercase tracking-wider px-2 py-1 bg-gray-100">
                          {article.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600 hidden lg:table-cell">{article.author}</td>
                      <td className="px-6 py-4 text-sm text-gray-600 hidden sm:table-cell">
                        {new Date(article.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleEdit(article)}
                            className="p-2 hover:bg-gray-100 transition-colors"
                            title="Edit"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                          </button>
                          <button
                            onClick={() => handleDelete(article.id)}
                            className={`p-2 transition-colors ${
                              deleteConfirm === article.id 
                                ? 'bg-red-600 text-white' 
                                : 'hover:bg-red-50 text-red-600'
                            }`}
                            title={deleteConfirm === article.id ? 'Click again to confirm' : 'Delete'}
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredArticles.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500">No articles found.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Create Article View */}
        {view === 'create' && (
          <ArticleEditor 
            onSave={handleSaveComplete}
            onCancel={() => setView('list')}
          />
        )}

        {/* Edit Article View */}
        {view === 'edit' && editingArticle && (
          <ArticleEditor 
            article={editingArticle}
            onSave={handleSaveComplete}
            onCancel={() => { setView('list'); setEditingArticle(null); }}
          />
        )}

        {/* Authors View */}
        {view === 'authors' && (
          <div className="bg-white shadow-sm p-6">
            <AuthorsEditor />
          </div>
        )}

        {/* Site Settings View */}
        {view === 'site-settings' && (
          <div className="bg-white shadow-sm">
            <SiteSettingsEditor />
          </div>
        )}

        {/* Account Settings View */}
        {view === 'settings' && (
          <div className="bg-white shadow-sm p-8 max-w-2xl">
            <h2 
              className="text-2xl font-bold mb-8"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Settings
            </h2>

            {/* Change Password */}
            <div className="mb-8">
              <h3 className="text-lg font-medium mb-4">Change Password</h3>
              <form onSubmit={handlePasswordChange} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Current Password
                  </label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    New Password
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black"
                    required
                    minLength={4}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-200 focus:outline-none focus:border-black"
                    required
                    minLength={4}
                  />
                </div>

                {passwordMessage && (
                  <div className={`px-4 py-3 text-sm ${
                    passwordMessage.type === 'success' 
                      ? 'bg-green-50 border border-green-200 text-green-700'
                      : 'bg-red-50 border border-red-200 text-red-700'
                  }`}>
                    {passwordMessage.text}
                  </div>
                )}

                <button
                  type="submit"
                  className="px-6 py-2 bg-black text-white text-sm font-medium uppercase tracking-wider hover:bg-gray-800 transition-colors"
                >
                  Update Password
                </button>
              </form>
            </div>

            {/* Markdown Mirrors */}
            <div className="pt-8 border-t border-gray-100">
              <h3 className="text-lg font-medium mb-1">Markdown Mirrors for AI & SEO</h3>
              <p className="text-sm text-gray-500 mb-4">
                Every article has a live Markdown mirror at <code className="bg-gray-100 px-1 rounded">/md/slug.md</code>. 
                Use the buttons below to download static copies for deployment or submission to AI indexes.
              </p>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                  <div>
                    <p className="font-medium">Export All Articles as Markdown</p>
                    <p className="text-sm text-gray-500">{articles.length} articles → individual <code>.md</code> files, organized by category</p>
                  </div>
                  <button
                    onClick={handleExportMarkdown}
                    disabled={exportingMd}
                    className="px-4 py-2 bg-black text-white text-sm uppercase tracking-wider hover:bg-gray-800 transition-colors disabled:opacity-50"
                  >
                    {exportingMd ? 'Exporting…' : '⬇ Export .md files'}
                  </button>
                </div>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                  <div>
                    <p className="font-medium">Regenerate sitemap.xml</p>
                    <p className="text-sm text-gray-500">Dynamic sitemap with all articles, images, news tags &amp; hreflang — ready to submit to Google Search Console</p>
                  </div>
                  <button
                    onClick={() => downloadSitemap(articles)}
                    className="px-4 py-2 border border-black text-black text-sm uppercase tracking-wider hover:bg-black hover:text-white transition-colors"
                  >
                    ⬇ Download sitemap.xml
                  </button>
                </div>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                  <div>
                    <p className="font-medium">Regenerate llms.txt Index</p>
                    <p className="text-sm text-gray-500">Updated index of all articles for AI crawlers (llmstxt.org standard)</p>
                  </div>
                  <button
                    onClick={handleExportLlmsTxt}
                    className="px-4 py-2 border border-black text-black text-sm uppercase tracking-wider hover:bg-black hover:text-white transition-colors"
                  >
                    ⬇ Download llms.txt
                  </button>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-100 rounded text-sm text-blue-700">
                  <strong>Live mirrors active:</strong> Any article is readable as Markdown right now at{' '}
                  <code>{window.location.origin}/md/<em>article-slug</em>.md</code>
                </div>
              </div>
            </div>

            {/* Data Management */}
            <div className="pt-8 border-t border-gray-100">
              <h3 className="text-lg font-medium mb-4">Data Management</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50">
                  <div>
                    <p className="font-medium">Reset to Default Articles</p>
                    <p className="text-sm text-gray-500">Remove all changes and restore original articles</p>
                  </div>
                  <button
                    onClick={() => {
                      if (confirm('Are you sure? This will delete all your changes and restore the default articles.')) {
                        localStorage.removeItem('elan_articles');
                        window.location.reload();
                      }
                    }}
                    className="px-4 py-2 border border-red-300 text-red-600 text-sm hover:bg-red-50 transition-colors"
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
